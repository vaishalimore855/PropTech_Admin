import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import http from "../BaseUrl/baseurl";
import axios from "axios";
const token = localStorage.getItem("token");

export const getSubscriptionList = createAsyncThunk("getSubscriptionList", async () => {
  const response = await axios.get("http://65.20.73.28:8090/api/subscriptions");
  console.log("SubscriptionResponse", response);
  return response.data;
});

export const getSubscriptionbyId = createAsyncThunk("getSubscriptionbyId", async (id) => {
  const response = await axios.get(`http://65.20.73.28:8090/api/subscriptions/${id}`);
  console.log("buyer resp", response.data);
  return response.data
});

const SubscriptionSlice = createSlice({
  name: "buyer",

  initialState: {
    Buyers: [],
    Buyer: {},
    KycUserid:{},
    status: "",
    error: "",
  },

  extraReducers(builder) {
    // add buyer
    builder
      .addCase(getSubscriptionList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getSubscriptionList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.Buyers = action.payload;
      })
      .addCase(getSubscriptionList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
     

      .addCase(getSubscriptionbyId.pending, (state, action) => {
        state.status = "loading";
        
      })
      .addCase(getSubscriptionbyId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.Buyer = action.payload;
      })
      .addCase(getSubscriptionbyId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});

export default SubscriptionSlice.reducer;
