import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import http from '../BaseUrl/baseurl'
import axios from "axios";

export const getMenuItemList = createAsyncThunk("getMenuItemList", async () => {
  const response = await axios.get("http://65.20.73.28:8090/api/managers");
  console.log("adminResponse", response.data);
  return response.data;
});
const token = localStorage.getItem("token");
 
export const getAdminRoleList = createAsyncThunk("getAdminRoleList", async ( ) => {
  const response = await axios.get(`http://65.20.73.28:8090/api/adminroles`,{
    headers: {
      authorization:token }
      
  });
  console.log("admin Role Response", response.data);
  return response.data;
});

export const getAdminRoleId = createAsyncThunk("getAdminRoleId", async ( id) => {
  const response = await axios.get(`http://65.20.73.28:8090/api/adminroles/${id}`,{
    headers: {
      authorization:token }
      
  });
  console.log("admin Role id Response", response.data);
  return response.data;
});


const AdminMenuSlice = createSlice({
  name: "Menu",

  initialState: {
    AdminRole:[],
    MenuItem: {},
    Role:{},
    status: "",
    error: "",
  },

  extraReducers(builder) {
    // add buyer

    builder
      .addCase(getMenuItemList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getMenuItemList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.MenuItem = action.payload;
      })
      .addCase(getMenuItemList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      //admin Role list
      .addCase(getAdminRoleList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getAdminRoleList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.AdminRole = action.payload;
      })
      .addCase(getAdminRoleList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      
      //admin Role id
      .addCase(getAdminRoleId.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getAdminRoleId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.Role = action.payload;
      })
      .addCase(getAdminRoleId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      
  },
});

export default AdminMenuSlice.reducer;
