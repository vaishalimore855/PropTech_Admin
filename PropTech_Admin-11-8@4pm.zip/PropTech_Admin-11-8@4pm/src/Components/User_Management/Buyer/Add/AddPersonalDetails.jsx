import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
// import { postBuyerData } from "../../../Redux/Slice/BuyerSlice";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from "formik";
import axios from "axios";
const AddPersonalDetails = () => {
  var navigate = useNavigate();

  const buyerValues = {
    fullname: "",
    email: "",
    phoneNumber: "",
    userrole: "",
    mobileverified: "",
    password: "",
  };
  const token = localStorage.getItem("token");
  const [buyer, setbuyer] = useState(buyerValues);
    const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  console.log("formErrors", formErrors);
  console.log("buyer", buyer);
  const handleChangeAddBuyerInput = (e) => {
    const { name, value } = e.target;
    setbuyer({
      ...buyer,
      [name]: value,
    });
  };

  
  const validate = (buyer) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!buyer.firstName) {
      errors.firstName = "Firstname cannot be blank";
    } else if (!buyer.lastname) {
      errors.lastname = "Lastname cannot be blank";
    } else if (!buyer.city) {
      errors.city = "City cannot be blank";
    } else if (!buyer.address) {
      errors.address = "Address cannot be blank";
    } else if (!buyer.phoneNumber) {
      errors.phoneNumber = "Mobile No. cannot be blank";
    } else if (buyer.phoneNumber.length > 10) {
      errors.phoneNumber = "Mobile number not valid";
    } else if (!buyer.email) {
      errors.email = "Cannot be blank";
    } else if (!regex.test(buyer.email)) {
      errors.email = "Invalid email format";
    } else if (!buyer.password) {
      errors.password = "Cannot be blank";
    } else if (buyer.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    }

    return errors;
  };

  const addBuyer = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        fullname: buyer.fullname,
        email: buyer.email,
        phoneNumber: buyer.phoneNumber,
        userrole: "buyer",
        mobileverified: true,
        password: buyer.password,
      }),
      headers: {
         "Content-Type": "application/json",
         "authorization":token
      },
    };

    fetch("http://65.20.73.28:8090/api/users", data)
      .then((response) => response.json())
      .then((data) => {
        console.log("data message", data);
        if (data?.status == true) {
          //  setbuyer(buyerValues)
          toast.success(data.message);
          navigate("/buyer");
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err));
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(buyer));

    if (Object.keys(formErrors).length == 0) {
      // addBuyer();
      navigate("/buyer")
    }
  };
  console.log("email", buyer.email);
  console.log("password", buyer.password);
  return (
    <>
      <ToastContainer />
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Full Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your full Name"
              name="fullname"
              value={buyer.fullname}
              onChange={(e) => handleChangeAddBuyerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.fullname}</p>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={buyer.phoneNumber}
              onChange={(e) => handleChangeAddBuyerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.phoneNumber}</p>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter Email"
              name="email"
              value={buyer.email}
              onChange={(e) => handleChangeAddBuyerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.email}</p>
          </div>

          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={buyer.password}
              onChange={(e) => handleChangeAddBuyerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.password}</p>
          </div>
        </div>
        
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={() => addBuyer()}
        >
          Submit
        </button>
      </form>
    </>
  );
};

export default AddPersonalDetails;
