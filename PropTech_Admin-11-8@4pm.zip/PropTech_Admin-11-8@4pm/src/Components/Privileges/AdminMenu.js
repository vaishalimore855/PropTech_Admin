import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { getMenuItemList } from "../../Redux/Slice/MenuSlice";

function AdminMenu() {
  const dispatch = useDispatch();
  const [adminMenuData, setAdminMenuData] = useState("");
  const MenuList = useSelector((state) => state.adminMenu.MenuItem);

  var navigate = useNavigate();

  useEffect(() => {
    dispatch(getMenuItemList());
    setAdminMenuData(MenuList);
  }, []);

  console.log("adminMenuData", adminMenuData);

  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            {/* <ToastContainer/> */}
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Admin Menu</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/Dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Admin Menu
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body" style={{ height: "200%" }}>
                    <div className="pt-4 pb-4 text-left">
                      <button
                        // class="btn btn-primary"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="/AddMenu" className="text-white">
                          + Add
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Link</th>
                              <th>Icon</th>
                              <th>ParentId</th>
                              <th>Priority</th>
                              <th>Type</th>
                            </tr>
                          </thead>

                          <tbody>
                            {MenuList.map((menu) => {
                              return (
                                <>
                                  <tr>
                                    <td>{menu.name}</td>
                                    <td>{menu.link}</td>
                                    <td>{menu.icon}</td>
                                    <td>{menu.parentid}</td>
                                    <td>{menu.priority}</td>
                                    <td>{menu.type}</td>
                                  </tr>
                                </>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  {/* </div> */}
                </div>
              </div>
            </div>
          </div>
          {/* <!-- end::main-content --> */}
        </div>
        {/* <!-- end::main --> */}
      </div>
    </div>
  );
}

export default AdminMenu;
