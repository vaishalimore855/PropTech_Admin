import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getMenuItemList } from "../../Redux/Slice/MenuSlice";
import { getAdminRoleList,getAdminRoleId } from "../../Redux/Slice/MenuSlice";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import Switch from "@mui/material/Switch";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";

function RoleManage() {
  var navigate = useNavigate();

  //status
  const [isChecked, setIsChecked] = useState(false);
  const { id } = useParams();
  const handleSwitchChange = () => {
    setIsChecked(!isChecked);
  };
  const label = { inputProps: { "aria-label": "Switch demo" } };
  const token = localStorage.getItem("token");
  // const defaultChecked = true;
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAdminRoleList());
    dispatch(getAdminRoleId(id));
  }, [id]);

  const adminRoleList = useSelector((state) => state.adminMenu.AdminRole);
  console.log("AdminRoleList----->", adminRoleList);
  const adminRoleId = useSelector((state) => state.adminMenu.Role);

  console.log("adminRoleId----->", adminRoleId);

  const managerValues = {
    fullname: "",
    email: "",
    role: "",
    phoneNumber: "",
    password: "",
    menu: [],
  };
  //admin role
  const adminRoleValue = {
    role: "",
  };
  const [role, setRole] = useState(adminRoleValue);
  const [menu, setMenu] = useState(managerValues);

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  console.log("formErrors", formErrors);
  console.log("menu", menu);
  console.log("role", role);

  const handleChangeAddMenuInput = (e) => {
    const { name, value } = e.target;
    setMenu({
      ...menu,
      [name]: value,
    });
  };

  const CreateAdminRole = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        role: role,
      }),
      headers: {
        "Content-Type": "application/json",
        authorization: token,
      },
    };

    fetch("http://65.20.73.28:8090/api/adminroles", data)
      .then((response) => response.json())
      .then((data) => {
        console.log("AdminRole response", JSON.stringify(data));
        setMenu(JSON.stringify(data));
        dispatch(getAdminRoleList());
      })
      .catch((err) => console.log(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // setFormErrors(validate(menu));

    if (Object.keys(formErrors).length == 0) {
      // CreateManager();
      CreateAdminRole();
    }
  };

  useEffect(() => {
    // CreateManager();
    CreateAdminRole();
  }, []);
  
  console.log(" create admin role ", role);

  //Delete AdminRole
  const [deleteConfirmation, setDeleteConfirmation] = useState({
    open: false,
    roleIdToDelete: null,
  });
  const deleteAdminRole = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/adminroles/${id}`, {
        headers: {
          authorization: token,
        },
      })
      .then((response) => response.data)
      .then((data) => {
        console.log("delete adminrole ", data);
        if (data.status != true) {
          setDeleteConfirmation({
            open: true,
            roleIdToDelete: data.id,
          });

          toast.success(data.message);
          // dispatch(getAdminRoleList());
        } else {
          toast.error(data.message);
        }

        // dispatch(getAdminRoleList());
      })
      .catch((err) => console.log(err));
  };

  const handleDeleteConfirmation = (roleId) => {
    setDeleteConfirmation({
      open: true,
      roleIdToDelete: roleId,
    });
  };

  const handleDeleteConfirmationClose = () => {
    setDeleteConfirmation({
      open: false,
      roleIdToDelete: null,
    });
  };

  const handleDeleteConfirmed = () => {
    console.log(deleteConfirmation);
    if (deleteConfirmation.id) {
      deleteAdminRole(deleteConfirmation.roleIdToDelete);
      
      
      dispatch(getAdminRoleId(id));
      handleDeleteConfirmationClose();
    }
  };
  const navigateTtoEditRoleManage = (id) => {
    navigate(`/edit-roleManage/${id}`);
  };
  
  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content" style={{ height: "700px" }}>
          <div className="container">
            {/* <ToastContainer/> */}

            <div className="page-header mt-5">
              <h4> Role Management</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/Dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Role Management
                  </li>
                </ol>
              </nav>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div
                  className="modal"
                  id="exampleModalToggle"
                  aria-hidden="true"
                  aria-labelledby="exampleModalToggleLabel"
                  tabindex="-1"
                >
                  <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5
                          className="modal-title"
                          id="exampleModalToggleLabel"
                        >
                          Add Role
                        </h5>
                        <button
                          type="button"
                          className="btn-close"
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        ></button>
                      </div>
                      <div className="modal-body">
                        <div className="row">
                          <div className="col-md-10 mb-3">
                            <input
                              type="text"
                              className="form-control"
                              name="role"
                              // value={role}
                              onChange={(e) => setRole(e.target.value)}
                            ></input>
                          </div>
                          <div className="col-md-2 mb-3">
                            <button
                              className="btn btn-primary"
                              onClick={() => CreateAdminRole()}
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-body" style={{ height: "200%" }}>
                    <div className="pt-4 pb-4 text-left">
                      <button
                        // className="btn btn-primary"
                        data-bs-toggle="modal"
                        href="#exampleModalToggle"
                        role="button"
                        // type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="" className="text-white">
                          + Add Role
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          style={{ textAlign: "center" }}
                          id="example2"
                          className="table table-striped table-bordered "
                        >
                          <thead>
                            <tr>
                              <th>ID</th>
                              <th>Name</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {adminRoleList.map((value) => (
                              <tr key={value.id}>
                                <td>{value.id}</td>
                                <td>{value.role}</td>
                                <td>
                                  <Switch
                                    checked={
                                      value.status === true
                                        ? isChecked
                                        : !isChecked
                                    }
                                    onChange={handleSwitchChange}
                                    color="primary"
                                    inputProps={{ "aria-label": "controlled" }}
                                  />
                                </td>
                                <td className="d-flex justify-content-center align-items-center ">
                                <button
                                      onClick={() => {
                                        navigateTtoEditRoleManage(value.id);
                                      }}
                                      className="btn btn-sm btn-icon  me-2   float-left btn-primary"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Edit"
                                    >
                                      <FontAwesomeIcon
                                        icon={faPencilSquare}
                                        style={{ color: "white" }}
                                      />
                                    </button>

                                  <button
                                    className="btn btn-sm btn-icon   me-2  btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                    onClick={() => deleteAdminRole(value.id)}
                                  >
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                          <div
                            className={`modal fade ${
                              deleteConfirmation.open ? "show" : ""
                            }`}
                            tabIndex="-1"
                            role="dialog"
                            style={{
                              display: deleteConfirmation.open
                                ? "block"
                                : "none",
                            }}
                          >
                            <div
                              className="modal-dialog modal-dialog-centered"
                              role="document"
                            >
                              <div className="modal-content">
                                <div className="modal-header">
                                  <h5 className="modal-title">
                                    Confirm Delete
                                  </h5>
                                  <button
                                    type="button"
                                    className="close"
                                    data-dismiss="modal"
                                    aria-label="Close"
                                    onClick={handleDeleteConfirmationClose}
                                  >
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div className="modal-body">
                                  Are you sure you want to delete this admin
                                  role?
                                </div>
                                <div className="modal-footer">
                                  <button
                                    type="button"
                                    className="btn btn-secondary"
                                    data-dismiss="modal"
                                    onClick={handleDeleteConfirmationClose}
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-danger"
                                    onClick={handleDeleteConfirmed}
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </table>
                      </div>
                    </div>
                  </div>
                  {/* </div> */}
                </div>
              </div>
            </div>
          </div>
          {/* <!-- end::main-content --> */}
        </div>
        {/* <!-- end::main --> */}
      </div>
    </div>
  );
}

export default RoleManage;
