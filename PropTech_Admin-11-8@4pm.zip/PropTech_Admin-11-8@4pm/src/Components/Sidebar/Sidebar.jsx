import React, { useEffect } from "react";
import logo from "../../assets/media/image/logo.png";
import logo_sm from "../../assets/media/image/logo-sm.png";
import logo_dark from "../../assets/media/image/logo-dark.png";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBarChart,
  faMoneyBill,
  faSearch,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { faCog } from "@fortawesome/free-solid-svg-icons";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import { faBars } from "@fortawesome/free-solid-svg-icons/faBars";
import { faExpand } from "@fortawesome/free-solid-svg-icons/faExpand";
import { faTh, faThLarge } from "@fortawesome/free-solid-svg-icons";
import { faComment } from "@fortawesome/free-solid-svg-icons";
import { faBell } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";
import {
  faChartBar,
  faChartBarAlt,
  faShoppingCart,
  faStore,
} from "@fortawesome/free-solid-svg-icons";
import { faFolder, faFile } from "@fortawesome/free-solid-svg-icons";
import { faMessageCircle } from "@fortawesome/free-solid-svg-icons";
import { faGlobe } from "@fortawesome/free-solid-svg-icons";
import { faAngleUp } from "@fortawesome/free-solid-svg-icons";
import { useSelector, useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ProfileSlice from "../../Redux/Slice/ProfileSlice";
import { getProfileData } from "../../Redux/Slice/ProfileSlice";
// import Header from "../admin/Header";
import ListSubheader from "@mui/material/ListSubheader";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import StarBorder from "@mui/icons-material/StarBorder";
import { faSeller } from "@fortawesome/free-solid-svg-icons";

const Sidebar = () => {
  const [open, setOpen] = React.useState(false);

  const handleClickList = () => {
    setOpen(!open);
  };
  const [openManagement, setOpenManagement] = React.useState(false);

  const handleClickManagerList = () => {
    setOpenManagement(!openManagement);
  };
  const [openSubscription, setOpenSubscription] = React.useState(false);

  const handleSubsriptionList = () => {
    setOpenSubscription(!openSubscription);
  };
  var navigate = useNavigate();
  const handleClick = () => {
    navigate("/profile");
    navigate("/Dashboard");
    navigate("/buyer");
    navigate("/investor");
    navigate("/sellers");
    navigate("/property-listing");
    navigate("/documentVerification");
  };

  return (
    <>
      <div
        className="navigation"
        style={{ overflow: "auto", height: "100vh", position: "fixed" }}
      >
        <div id="logo">
          <h3 style={{ fontWeight: "bold" }}>PropTech</h3>
        </div>

        <header className="navigation-header">
          <figure className="avatar avatar-state-success">
            <img
              src="https://via.placeholder.com/128X128"
              className="rounded-circle"
              alt="image"
            />
          </figure>
          <div>
            <h5>Zeeshaan Pathan</h5>
            <p className="text-muted">Administrator</p>
            <ul className="nav">
              <li className="nav-item">
                <Link
                  to="/profile"
                  className="btn nav-link bg-info-bright"
                  title="Profile"
                  data-toggle="tooltip"
                >
                  <FontAwesomeIcon icon={faUser} style={{ marginTop: 4 }} />
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  to="/"
                  className="btn nav-link bg-success-bright"
                  title="Settings"
                  data-toggle="tooltip"
                >
                  <FontAwesomeIcon icon={faCog} style={{ marginTop: 4 }} />
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  to="/"
                  className="btn nav-link bg-danger-bright"
                  title="Logout"
                  data-toggle="tooltip"
                >
                  <FontAwesomeIcon
                    icon={faSignOutAlt}
                    style={{ marginTop: 4 }}
                  />
                </Link>
              </li>
            </ul>
          </div>
        </header>

        <div className="navigation-menu-body">
          <ul>
            <li>
              <Link to="/Dashboard">
                <FontAwesomeIcon
                  icon={faChartBar}
                  className="me-3 nav-link-icon"
                />

                <span>Dashboard</span>
              </Link>
            </li>

            <List>
              <ListItemButton onClick={handleClickList}>
                <ListItemIcon>
                  <FontAwesomeIcon
                    icon={faUser}
                    style={{ marginLeft: "20px" }}
                  />
                </ListItemIcon>
                <Link>User Management</Link>{" "}
                {open ? <ExpandLess /> : <ExpandMore />}
              </ListItemButton>
              <Collapse in={open} timeout="auto" unmountOnExit>
                <Link to="/buyer">
                  <List component="div" disablePadding>
                    <ListItemButton sx={{ pl: 4 }}>
                      <ListItemIcon>
                        <FontAwesomeIcon icon={faShoppingCart} />
                      </ListItemIcon>
                      <Link to="/buyer">Buyer</Link>
                    </ListItemButton>
                  </List>
                </Link>
              </Collapse>
              <Collapse in={open} timeout="auto" unmountOnExit>
                <Link to="/sellers">
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faStore} />
                    </ListItemIcon>
                    <Link to="/sellers">Seller</Link>{" "}
                  </ListItemButton>
                </List>
                </Link>
              </Collapse>
              <Collapse in={open} timeout="auto" unmountOnExit>
                <Link to="/investor">
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faMoneyBill} />
                    </ListItemIcon>
                    <Link to="/investor">Investor</Link>{" "}
                  </ListItemButton>
                </List>
                </Link>
              </Collapse>
            </List>
            <List>
              <ListItemButton onClick={handleClickManagerList}>
                <ListItemIcon>
                  <FontAwesomeIcon
                    icon={faUser}
                    style={{ marginLeft: "20px" }}
                  />
                </ListItemIcon>
                <Link>Manager</Link>{" "}
                {openManagement ? <ExpandLess /> : <ExpandMore />}
              </ListItemButton>
              <Collapse in={openManagement} timeout="auto" unmountOnExit>
                <Link to="/managerrole">
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faShoppingCart} />
                    </ListItemIcon>
                    <Link to="/RoleManage">Manager Role</Link>{" "}
                  </ListItemButton>
                </List>
                </Link>
              </Collapse>
              <Collapse in={openManagement} timeout="auto" unmountOnExit>
               <Link  to="/managerlist">
               <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faStore} />
                    </ListItemIcon>
                    <Link to="/managerlist">Manager List</Link>{" "}
                  </ListItemButton>
                </List>
               </Link>
              </Collapse>
            </List>

            <List>
              <ListItemButton onClick={handleSubsriptionList}>
                <ListItemIcon>
                  <FontAwesomeIcon
                    icon={faUser}
                    style={{ marginLeft: "20px" }}
                  />
                </ListItemIcon>
                <Link>Subscription</Link>{" "}
                {openSubscription ? <ExpandLess /> : <ExpandMore />}
              </ListItemButton>
              <Collapse in={openSubscription} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faShoppingCart} />
                    </ListItemIcon>
                    <Link to="/subscription" style={{ marginRight: 25 }}>
                      Subscription Plan
                    </Link>{" "}
                  </ListItemButton>
                </List>
              </Collapse>
              <Collapse in={openSubscription} timeout="auto" unmountOnExit>
                <Link to="/subscriptionHistory">
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>
                      <FontAwesomeIcon icon={faStore} />
                    </ListItemIcon>
                    <Link >Subscription History</Link>{" "}
                  </ListItemButton>
                </List>
                </Link>
              </Collapse>
            </List>
            
            <li>
              <Link to="/property-listing">
                <i className="ti-agenda nav-link-icon"></i>
                <span>Property Listing</span>
              </Link>
            </li>

            <li>
              <Link to="/property-verification">
                <i className="ti-agenda nav-link-icon"></i>
                <span>Property Verification</span>
              </Link>
            </li>
           
         </ul>
        </div>
      </div>

      <div id="main">{/* <Header /> */}</div>
    </>
  );
};

export default Sidebar;
