import React, { useState, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from "formik";
import axios from "axios";
const AddSubscriptionPlan = () => {
  var navigate = useNavigate();

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4> Subscription</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Subscription Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Add Subscription Plan
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left"></div>
                    <div className="card">
                      <div className="card-body">
                        <ToastContainer />
                        {/* <div class="main-content">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="card">
                                <div class="card-body">
                                 
                                </div>
                              </div>
                            </div>
                          </div>
                        </div> */}
                        <form class="needs-validation" novalidate="">
                                    <div class="form-row">
                                      <div class="col-md-4 mb-3">
                                        <label for="validationCustom01">
                                          Plan Name
                                        </label>
                                        <input
                                          type="text"
                                          class="form-control"
                                          id="validationCustom01"
                                          placeholder="enter your plan name"
                                          required=""
                                        />
                                        <div class="valid-feedback">
                                          Looks good!
                                        </div>
                                      </div>
                                      <div class="col-md-4 mb-3">
                                        <label for="validationCustom02">
                                          Price
                                        </label>
                                        <input
                                          type="text"
                                          data-input-mask="Price"
                                          class="form-control"
                                          id="validationCustom02"
                                          placeholder="1000₹"
                                          required=""
                                        />
                                        <div class="valid-feedback">
                                          Looks good!
                                        </div>
                                      </div>
                                    </div>
                                    <div class="form-row">
                                      <div class="col-md-12 mb-3">
                                        <label for="validationCustom04">
                                          Feature
                                        </label>
                                      </div>
                                      <div class="col-md-12 mb-3">
                                        <textarea
                                          id="summernote"
                                          rows="5"
                                          cols="75"
                                        ></textarea>
                                      </div>
                                      <div class="invalid-feedback">
                                        Please provide a valid Feature.
                                      </div>
                                    </div>

                                    <button
                                      class="btn btn-primary"
                                      type="submit"
                                    >
                                      Submit{" "}
                                    </button>
                                  </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default AddSubscriptionPlan;
