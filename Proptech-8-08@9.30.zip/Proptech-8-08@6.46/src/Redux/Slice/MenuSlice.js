import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import http from '../BaseUrl/baseurl'
import axios from "axios";

export const getMenuItemList = createAsyncThunk("getMenuItemList", async () => {
  const response = await axios.get("http://65.20.73.28:8090/api/managers");
  console.log("adminResponse", response.data);
  return response.data;
});
const token = localStorage.getItem("token");
 
export const getAdminRoleList = createAsyncThunk("getAdminRoleList", async ( ) => {
  const response = await axios.get(`http://65.20.73.28:8090/api/adminroles`,{
    headers: {
      authorization:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluQHByb3B0ZWNoLmNvbSIsInVzZXJJZCI6MSwiaWF0IjoxNjkxNDI1MDc5LCJleHAiOjE2OTE1MTE0Nzl9.ndFF0ma4QcnEuthfTBb7xAxaRvyJyDcuCgHLr4dnI5s" }
  });
  console.log("admin Role Response", response.data);
  return response.data;
});


const AdminMenuSlice = createSlice({
  name: "Menu",

  initialState: {
    AdminRole:[],
    MenuItem: {},
    status: "",
    error: "",
  },

  extraReducers(builder) {
    // add buyer

    builder
      .addCase(getMenuItemList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getMenuItemList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.MenuItem = action.payload;
      })
      .addCase(getMenuItemList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      //admin Role
      .addCase(getAdminRoleList.pending, (state, action) => {
        state.status = "loading";
      })
      .addCase(getAdminRoleList.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.AdminRole = action.payload;
      })
      .addCase(getAdminRoleList.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      
  },
});

export default AdminMenuSlice.reducer;
