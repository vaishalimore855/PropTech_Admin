import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";

import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getPropertyList } from "../../Redux/Slice/PropertyVerificationSlice";
const PropertyVerification = () => {
  const dispatch = useDispatch();

  // Dispatch the action to fetch the property list when the component mounts
  useEffect(() => {
    dispatch(getPropertyList());
  }, [dispatch]);

  // Access the PropertyList from the Redux store
  const propertyList = useSelector(
    (state) => state.propertyverification.PropertyList
  );

  console.log("list", JSON.stringify(propertyList));

  //   const { userid } = useParams();
  var navigate = useNavigate();

  const navigateToEditBuyer = (id) => {
    navigate(`/edit-proprty/${id}`);
  };

  const navigateToViewPropertyVerification = (id) => {
    navigate(`/view-propertyverification/${id}`);
  };
  const token = localStorage.getItem("token");

  const deletProprty = (id) => {
    axios
      .delete(`http://localhost:8090/api/users/${id}`)
      .then((response) => response.data)
      .then((data) => {
        console.log("delete buyer ", data);
        if (data.status != true) {
          //   dispatch(getBuyerList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        // dispatch(getBuyerList());
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Property Verification</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Property Verification
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link
                          to="/add-propertyverification"
                          className="text-white"
                        >
                          + Add Property
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Id</th>
                              <th>Property Name</th>
                              <th>User Name</th>
                              <th>Ownership Proof</th>
                              <th>Index II Document</th>
                              <th>Verification Status</th>
                              <th>Actions</th>
                            </tr>
                          </thead>

                          <tbody style={{ textAlign: "center" }}>
                            {propertyList.map((property, index) => (
                              <tr key={index}>
                                <td>{index+1}</td>
                                <td>{property?.propertyData?.title}</td>
                                <td>{property?.userData?.fullname}</td>
                                <td>
                                  <div className="d-flex justify-content-center align-items-center">
                                    <img
                                      src={`${property?.OwnershipProof}`}
                                      alt=""
                                      width="40%"
                                      height="40%"
                                    />
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex justify-content-center align-items-center">
                                    <img
                                      src={`${property?.IndexIIDoc}`}
                                      alt=""
                                      width="40%"
                                      height="40%"
                                    />
                                  </div>
                                </td>

                               
                                <td>
                                  {
                                    property?.propertyData?.propertyStatus == 'false'?
                                    <span class="badge badge-info">Pending</span>
                                    :
                                    property?.propertyData?.propertyStatus == "In Progress"?
                                    <span class="badge badge-warning">In Progress</span>
                                    :
                                    property?.propertyData?.propertyStatus == "Reject"?
                                    <span class="badge badge-warning">Reject</span>
                                    :
                                    <span class="badge badge-success">Verified</span>
                                  }
                               </td>
                                <td>
                                  <button
                                    onClick={() =>
                                      navigateToViewPropertyVerification(property.id)
                                    }
                                    className="btn btn-sm btn-icon me-2 float-left btn-info"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="View"
                                  >
                                    <FontAwesomeIcon
                                      icon={faEye}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default PropertyVerification;
