// import React, { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// //icons
// import "bootstrap/dist/css/bootstrap.min.css";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faEye } from "@fortawesome/free-solid-svg-icons";

// import { useSelector, useDispatch } from "react-redux";
// import axios from "axios";
// import { useParams } from "react-router-dom";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import { getPropertybyId } from "../../Redux/Slice/PropertyVerificationSlice";
// const ViewPropertyVerification = () => {
//   const { id } = useParams();
//   const dispatch = useDispatch();
//   useEffect(() => {
//     // Dispatch the getPropertybyId action when the component mounts
//     dispatch(getPropertybyId(id));
//   }, [dispatch, id]);

//   const propertyId = useSelector(
//     (state) => state.propertyverification.PropertyId
//   );

//   console.log("propertyId", propertyId);

//   //   const { userid } = useParams();
//   var navigate = useNavigate();

//   const token = localStorage.getItem("token");

//   // const deletProprty = (id) => {
//   //   axios
//   //     .delete(`http://localhost:8090/api/users/${id}`)
//   //     .then((response) => response.data)
//   //     .then((data) => {
//   //       console.log("delete buyer ", data);
//   //       if (data.status != true) {
//   //         //   dispatch(getBuyerList());
//   //         toast.success(data.message);
//   //       } else {
//   //         toast.error(data.message);
//   //       }

//   //       // dispatch(getBuyerList());
//   //     })
//   //     .catch((err) => console.log(err));
//   // };

//   return (
// <div>
//   {/* <!-- begin::main --> */}
//   <div id="main">
//     {/* <!-- begin::main-content --> */}
//     <main className="main-content">
//       <div className="container">
//         <ToastContainer />
//         {/* <!-- begin::page-header --> */}
//         <div className="page-header mt-5">
//           <h4> View Property Verification</h4>
//           <nav aria-label="breadcrumb">
//             <ol className="breadcrumb">
//               <li className="breadcrumb-item">
//                 <Link to="/homepage">Home</Link>
//               </li>
//               <li className="breadcrumb-item">
//                 <Link to="#">Property Management Screen</Link>
//               </li>
//               <li className="breadcrumb-item active" aria-current="page">
//                 View Property Verification
//               </li>
//             </ol>
//           </nav>
//         </div>
//         {/* <!-- end::page-header --> */}

//         <div className="row">
//           <div className="col-md-12">
//             <div className="card">
//               <div className="card-body">
//                 <div className="pt-4 pb-4 text-left"></div>
//                 <div className="card">
//                   <div className="card-body">
//                     <div className="view-document-main col-lg-12">
//                       <dl className="row ">
//                         <dt className="col-2">OwnershipProof:</dt>
//                         <dd className="col-6">
//                           {propertyId?.PropertyVerificationdata
//                             ?.OwnershipProof ? (
//                             <div
//                               style={{
//                                 width: "330px",
//                                 height: "200px",
//                                 border: "1px black solid",
//                                 padding: "10px",
//                                 marginRight: "20px",
//                                 borderRadius: "10px",
//                               }}
//                             >
//                               <img
//                                 src={`data:image/png;base64, ${propertyId?.PropertyVerificationdata?.OwnershipProof}`}
//                                 alt=""
//                                 width="100%"
//                                 height="100%"
//                               />
//                             </div>
//                           ) : (
//                             <div>No OwnershipProof Image</div>
//                           )}
//                         </dd>
//                         <dt className="col-2"> Id:</dt>
//                         <dd className="col-2">
//                           <div
//                             style={{
//                               width: "100px",
//                               height: "50px",
//                               border: "1px black solid",
//                               padding: "10px",
//                               // marginRight: "10px",
//                               textAlign: "center",
//                               fontWeight: "bold",
//                               fontSize: "18px",
//                             }}
//                           >
//                             {
//                               propertyId?.PropertyVerificationdata
//                                 ?.id
//                             }
//                           </div>
//                         </dd>

//                       </dl>
//                       <dl className="row">
//                         <dt className="col-2">IndexIIDoc:</dt>
//                         <dd className="col-6">
//                           {propertyId?.PropertyVerificationdata
//                             ?.IndexIIDoc ? (
//                             <div
//                               style={{
//                                 width: "330px",
//                                 height: "200px",
//                                 border: "1px black solid",
//                                 padding: "10px",
//                                 marginRight: "20px",
//                                 borderRadius: "10px",
//                               }}
//                             >
//                               <img
//                                 src={`data:image/jpeg;base64, ${propertyId?.PropertyVerificationdata?.IndexIIDoc}`}
//                                 alt=""
//                                 width="100%"
//                                 height="100%"
//                               />
//                             </div>
//                           ) : (
//                             <div>No IndexIIDoc Image</div>
//                           )}
//                         </dd>
//                         <dt className="col-2">Property Id:</dt>
//                         <dd className="col-2">
//                           <div
//                             style={{
//                               width: "100px",
//                               height: "50px",
//                               border: "1px black solid",
//                               padding: "10px",
//                               marginRight: "20px",
//                               textAlign: "center",
//                               fontWeight: "bold",
//                               fontSize: "18px",
//                             }}
//                           >
//                             {
//                               propertyId?.PropertyVerificationdata
//                                 ?.propertyid
//                             }
//                           </div>
//                         </dd>
//                       </dl>
//                     </div>

//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </main>
//     {/* <!-- end::main-content --> */}
//   </div>
//   {/* <!-- end::main --> */}
// </div>
//   );
// };

// export default ViewPropertyVerification;

import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { useSelector, useDispatch } from "react-redux";
import { getPropertybyId } from "../../Redux/Slice/PropertyVerificationSlice";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useParams } from "react-router-dom";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";

const ViewPropertyVerification = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  useEffect(() => {
    // Dispatch the getPropertybyId action when the component mounts
    dispatch(getPropertybyId(id));
  }, [dispatch, id]);

  const propertyId = useSelector(
    (state) => state.propertyverification.PropertyId
  );

  console.log("propertyId", propertyId);

  const token = localStorage.getItem("token");

  // State to manage the visibility of the popup
  const [showPopup, setShowPopup] = useState(false);

  // Function to toggle the popup visibility
  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4> View Property Verification</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Property Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    View Property Verification
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left"></div>
                    <div className="card">
                      <div className="card-body">
                        <div className="view-document-main col-lg-12">
                          <dl className="row ">
                            <dt className="col-2">OwnershipProof:</dt>
                            <dd className="col-4">
                              {propertyId?.PropertyVerificationdata
                                ?.OwnershipProof ? (
                                <div
                                  style={{
                                    width: "200px",
                                    height: "200px",
                                    border: "1px black solid",
                                    padding: "10px",
                                    marginRight: "20px",
                                    borderRadius: "10px",
                                  }}
                                >
                                  <img
                                    src={`${propertyId?.PropertyVerificationdata?.OwnershipProof}`}
                                    alt=""
                                    width="100%"
                                    height="100%"
                                  />
                                </div>
                              ) : (
                                <div>No OwnershipProof Image</div>
                              )}
                            </dd>
                            <dt className="col-6">
                            <h6><b>User Name: &nbsp;&nbsp;</b> {propertyId?.userData?.fullname}</h6>
                            <h6><b>Email: &nbsp;&nbsp;</b> {propertyId?.userData?.email}</h6>
                            <h6><b>Phone Number: &nbsp;&nbsp;</b> {propertyId?.userData?.phoneNumber}</h6>
                            <h6><b>Address: &nbsp;&nbsp;</b> {propertyId?.userData?.address},{propertyId?.userData?.city}</h6>
                           </dt>
                           
                          </dl>
                          <dl className="row">
                            <dt className="col-2">IndexIIDoc:</dt>
                            <dd className="col-4">
                              {propertyId?.PropertyVerificationdata
                                ?.IndexIIDoc ? (
                                <div
                                  style={{
                                    width: "200px",
                                    height: "200px",
                                    border: "1px black solid",
                                    padding: "10px",
                                    marginRight: "20px",
                                    borderRadius: "10px",
                                  }}
                                >
                                  <img
                                    src={propertyId?.PropertyVerificationdata?.IndexIIDoc}
                                    alt=""
                                    width="100%"
                                    height="100%"
                                  />
                                </div>
                              ) : (
                                <div>No IndexIIDoc Image</div>
                              )}
                            </dd>
                            <dt className="col-6">
                            <h6><b>Property Name:&nbsp;&nbsp;</b> {propertyId?.propertyData?.title}</h6>
                            <h6><b>Property category:&nbsp;&nbsp;</b> {propertyId?.propertyData?.category}</h6>
                            <h6><b>Property Type:&nbsp;&nbsp;</b> {propertyId?.propertyData?.subcategory}</h6>
                            <h6><b>Price:&nbsp;&nbsp;</b> {propertyId?.propertyData?.price}</h6>
                            <h6><b>Description:&nbsp;&nbsp;</b> {propertyId?.propertyData?.description}</h6>
                           </dt>
                          </dl>
                        </div>
                      </div>
                      <div className="row ">
                        <div>
                         <div className="col-md-12 d-flex justify-content-end align-items-end">
                           <Button variant="contained">Approve</Button>
                            <Button variant="contained" onClick={togglePopup}>
                              Reject
                            </Button>
                            {showPopup && (
                              <div
                                className="popup-overlay bordered"
                                style={{
                                  backgroundColor: "gray",
                                  width: "100%",
                                  height: "300px",
                                }}
                              >
                                <div className="popup">
                                  <div className="popup-header">
                                    <h3>Please Add the Reasons</h3>
                                    <button
                                      className="popup-close"
                                      onClick={togglePopup}
                                    >
                                      close
                                    </button>
                                  </div>
                                  <div className="popup-content" style={{marginTop:"40%",marginLeft:"30%"}}>
                                    <Button variant="contained">Submit</Button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>

      {/* <!-- end::main --> */}
    </div>
  );
};

export default ViewPropertyVerification;
