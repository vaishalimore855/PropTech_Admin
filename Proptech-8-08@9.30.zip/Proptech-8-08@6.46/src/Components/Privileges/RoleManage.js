import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getMenuItemList } from "../../Redux/Slice/MenuSlice";
import { getAdminRoleList } from "../../Redux/Slice/MenuSlice";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import Switch from "@mui/material/Switch";

function RoleManage() {
  var navigate = useNavigate();

  //status

  const label = { inputProps: { "aria-label": "Switch demo" } };
  const token = localStorage.getItem("token");
  // const defaultChecked = true;
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getAdminRoleList());
  }, []);

  const adminRoleList = useSelector((state) => state);
  console.log("AdminRoleList----->", adminRoleList);
  const roleList = adminRoleList?.adminMenu?.AdminRole;
  console.log("roleList", roleList);
  const managerValues = {
    fullname: "",
    email: "",
    role: "",
    phoneNumber: "",
    password: "",
    menu: [],
  };
  //admin role
  const adminRoleValue = {
    role: "",
  };
  const [role, setRole] = useState(adminRoleValue);
  const [menu, setMenu] = useState(managerValues);

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  console.log("formErrors", formErrors);
  console.log("menu", menu);
  console.log("role", role);

  const handleChangeAddMenuInput = (e) => {
    const { name, value } = e.target;
    setMenu({
      ...menu,
      [name]: value,
    });
  };

  const handleChangeAddAdminRoleInput = (e) => {
    const { name, value } = e.target;
    setRole({
      ...role,
      [name]: value,
    });
  };

  const CreateManager = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        fullname: "Jon sena",
        email: "jonsena@proptech.com",
        role: "2",
        phoneNumber: "9876543210",
        password: "Jon@123",
        menu: ["1", "2", "3"],
      }),
      headers: {
        "Content-Type": "application/json",
        authorization:
          "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InNhbnRvc2guY2lzY29uaWNAZ21haWwuY29tIiwidXNlcklkIjoxLCJpYXQiOjE2OTEzOTAyMDQsImV4cCI6MTY5MTQ3NjYwNH0.WB_FThEK4zJ8n6xaEXfc5qVXKC34k_GiCdqy1Vuqcfk",},
    };

    fetch("http://localhost:8090/api/managers", data)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setMenu(JSON.stringify(data));
      })
      .catch((err) => console.log(err));
  };

  const CreateAdminRole = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        role : "Agent"
    }),
      headers: {
        "Content-Type": "application/json",
        authorization:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFkbWluQHByb3B0ZWNoLmNvbSIsInVzZXJJZCI6MSwiaWF0IjoxNjkxNDI1MDc5LCJleHAiOjE2OTE1MTE0Nzl9.ndFF0ma4QcnEuthfTBb7xAxaRvyJyDcuCgHLr4dnI5s"
          },
    };

    fetch("http://65.20.73.28:8090/api/adminroles", data)
      .then((response) => response.json())
      .then((data) => {
        console.log("AdminRole response", JSON.stringify(data));
        setMenu(JSON.stringify(data));
      })
      .catch((err) => console.log(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // setFormErrors(validate(menu));

    if (Object.keys(formErrors).length == 0) {
      // CreateManager();
      // CreateAdminRole();
      navigate("/RoleManage");
    }
  };

  useEffect(() => {
    // CreateManager();
    CreateAdminRole();
  }, []);
  console.log(" create manager ", menu);
  console.log(" create admin role ", role);

  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            {/* <ToastContainer/> */}
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4> Role Management</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/Dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Role Management
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div
                  className="modal"
                  id="exampleModalToggle"
                  aria-hidden="true"
                  aria-labelledby="exampleModalToggleLabel"
                  tabindex="-1"
                >
                  <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5
                          className="modal-title"
                          id="exampleModalToggleLabel"
                        >
                          Add Role
                        </h5>
                        <button
                          type="button"
                          className="btn-close"
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        ></button>
                      </div>
                      <div className="modal-body">
                        <div className="row">
                          <div className="col-md-10 mb-3">
                            <input
                              type="text"
                              className="form-control"
                              name="role"
                            
                            onChange={handleChangeAddAdminRoleInput}
                            ></input>
                          </div>
                          <div className="col-md-2 mb-3">
                            <button
                              className="btn btn-primary"
                              onClick={() => CreateAdminRole()}
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                      {/* <div className="modal-footer">
                                                <button className="btn btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal">Open second modal</button>
                                            </div> */}
                    </div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-body" style={{ height: "200%" }}>
                    <div className="pt-4 pb-4 text-left">
                      <button
                        // className="btn btn-primary"
                        data-bs-toggle="modal"
                        href="#exampleModalToggle"
                        role="button"
                        // type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="" className="text-white">
                          + Add Role
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {roleList.map((value) => (
                              <tr key={value.role}>
                                <td>{value.role}</td>
                                <td>
                                  <Switch {...label} defaultChecked />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  {/* </div> */}
                </div>
              </div>
            </div>
          </div>
          {/* <!-- end::main-content --> */}
        </div>
        {/* <!-- end::main --> */}
      </div>
    </div>
  );
}

export default RoleManage;
