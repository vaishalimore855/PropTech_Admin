import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import {
  getSellerList,
  getKycSellerUserid,
} from "../../../Redux/Slice/SellerSlice";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const Seller = () => {
  const { userid } = useParams();
  const dispatch = useDispatch();
  const SellerList = useSelector((state) => state.seller.Sellers);
  console.log("SellerList", SellerList);
  
  var navigate = useNavigate();

  useEffect(() => {
    dispatch(getSellerList());
    
  }, [userid]);

  const navigateToEditSeller = (id) => {
    navigate(`/edit-seller/${id}`);
  };

  const navigateToViewSeller = (id) => {
    navigate(`/view-seller/${id}`);
  };

  const navigateToKycEditSeller = (userid) => {
    navigate(`/edit-seller/${userid}`);
  };

  const navigateToKycViewSeller = (userid) => {
    navigate(`/view-seller/${userid}`);
  };

  const deletSeller = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/users/${id}`)
      .then((response) => response.data)
      .then((data) => {
        console.log("delete seller ", data);
        if (data.status != true) {
          dispatch(getSellerList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        dispatch(getSellerList());
      })
      .catch((err) => console.log(err));
  };
  //delete seller Kyc
  const deletKycSeller = (userid) => {
    axios
      .delete(`http://65.20.73.28:8090/api/users/delete-kyc/${userid}`)
      .then((response) => response.data)
      .then((data) => {
        console.log("delete kyc seller ", data);
        if (data.status != true) {
          dispatch(getKycSellerUserid());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        dispatch(getKycSellerUserid());
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Seller</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Sellers
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="/add-seller" className="text-white">
                          + Add Seller
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Contact</th>
                              <th>Email</th>
                              <th> User Role</th>
                              <th>Status</th>
                              {/* <th>AadharFront</th>
                              <th>AadharBack</th>
                              <th>Pan</th>
                              <th>User ID</th> */}
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {SellerList.map((seller) => {
                              return (
                                <tr>
                                  <td>{seller.fullname}</td>
                                  <td>{seller.phoneNumber}</td>
                                  <td>{seller.email}</td>
                                  <td>{seller.userrole}</td>
                                  <td>2011/04/25</td>
                                  <td className="d-flex ">
                                    <button
                                      onClick={() =>
                                        navigateToViewSeller(seller.id)
                                      }
                                      className="btn btn-sm btn-icon  me-2  float-left btn-info"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="View"
                                    >
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                    <button
                                      onClick={() => {
                                        navigateToEditSeller(seller.id);
                                      }}
                                      className="btn btn-sm btn-icon  me-2   float-left btn-primary"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Edit"
                                    >
                                      <FontAwesomeIcon
                                        icon={faPencilSquare}
                                        style={{ color: "white" }}
                                      />
                                    </button>

                                    <button
                                      className="btn btn-sm btn-icon   me-2  btn-danger"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Delete"
                                      onClick={() => deletSeller(seller.id)}
                                    >
                                      <FontAwesomeIcon
                                        icon={faTrashAlt}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default Seller;
