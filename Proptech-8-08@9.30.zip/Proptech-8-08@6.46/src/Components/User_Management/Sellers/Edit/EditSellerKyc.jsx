import React, { useState,useRef, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {getKycSellerUserid } from "../../../../Redux/Slice/SellerSlice";
import { useNavigate } from "react-router-dom";

const EditSellerKyc = () => {
  var navigate = useNavigate();
  const { userid } = useParams();
  const adharFrontRef = useRef(null);
  const adharBackRef = useRef(null);
  const panCardRef = useRef(null);
  const [userId, setUserId] = useState(""); // Set the user ID here
  console.log("userId", userId);
  const dispatch = useDispatch();
  const kycuserId = useSelector((state) => state.seller.KycUserid);
  console.log("kycuserId .......", JSON.stringify(kycuserId));

  const [editedKycSeller, setEditedKycSeller] = useState({
    adharBack:"",
    adharFront:"",
    panCard:"",
    userId:"",
  });
  useEffect(() => {
    dispatch(getKycSellerUserid(userid));
  }, [userid]);

  useEffect(() => {
    setEditedKycSeller({
      adharFront:kycuserId?.adharFront,
      adharBack:kycuserId?.adharBack,
      panCard:kycuserId?.pan,
      userid:kycuserId?.userid
    });
  }, [kycuserId]);


  const handleFileChange = (event, inputName) => {
    const file = event.target.files[0];

    if (file) {
      setEditedKycSeller((prevSelectedFiles) => ({
        ...prevSelectedFiles,
        [inputName]: file,
      }));
    }
  };


  const handleEditKycProfile = (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedKycSeller),
      headers: {
        "Content-type": "application/json",
      },
    };

    fetch(`http://65.20.73.28:8090/api/profile/17`, data)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/sellers");
      })
      .catch((err) => console.log(err));
  };

  return (
    
    <>
    {/* <ToastContainer /> */}
    <form
      style={{ height: "auto" }}
      // onSubmit={handleSubmit}
    >
      <div className="row">
        <div className="col-md-6 mb-3">
          {/* {editedKycSeller.adharBack && (
            <div>
              <img
                src={(editedKycSeller.adharBack)}
                alt="Adhar Front"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )} */}

          <label for="validationCustom01">Aadhar Back </label>

          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={adharBackRef}
            onChange={(event) => handleFileChange(event, "adharBack")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => adharBackRef.current.click()}
          >
            Add Adhar Front
          </button>
        </div>
        <div className="col-md-6 mb-3">
          {/* {editedKycSeller.adharFront && (
            <div>
              <img
                src={(editedKycSeller.adharFront)}
                alt="Adhar Front"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )} */}
          <label for="validationCustom04">Aadhar front</label>

          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={adharFrontRef}
            onChange={(event) => handleFileChange(event, "adharFront")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => adharFrontRef.current.click()}
          >
            Add Adhar Back
          </button>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6 mb-3">
          {/* {editedKycSeller.panCard && (
            <div>
              <img
                src={(editedKycSeller.panCard)}
                alt="Adhar Back"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )} */}
          <label for="validationCustom04">Pan</label>
          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={panCardRef}
            onChange={(event) => handleFileChange(event, "panCard")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => panCardRef.current.click()}
          >
            Add Pan Card
          </button>{" "}
        </div>

        <div className="col-md-6 mb-3">
          <label for="validationCustom04">User Id</label>
          <input
            className="form-control"
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="Enter User ID"
          />
        </div>
      </div>

      <button
        className="btn btn-primary mt-2"
        type="submit"
        onClick={() => handleEditKycProfile()}
      >
        Submit
      </button>
    </form>
  </>
  );
};

export default EditSellerKyc;
