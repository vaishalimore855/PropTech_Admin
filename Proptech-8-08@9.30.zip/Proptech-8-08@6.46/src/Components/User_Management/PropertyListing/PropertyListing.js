import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { useSelector, useDispatch } from "react-redux";
import { getPropertyList } from "../../../Redux/Slice/PropertyListingSlice";
import axios from "axios";

import { ToastContainer, toast } from "react-toastify";
const PropertyListing = () => {
  const [propertyData, setPropertyData] = useState("");
  const dispatch = useDispatch();
  const PropertyList = useSelector((state) => state.propertylisting.property);

  useEffect(() => {
    dispatch(getPropertyList());
    setPropertyData(PropertyList);
  }, [PropertyList]);

  var navigate = useNavigate();
  // const handleClick = () => {
  //   navigate("/add-property");
  //   navigate("/edit-property");
  // };
  const navigateToEditProperty = (id) => {
    navigate(`/edit-property/${id}`);
  };
  console.log("propertyData", propertyData);

  //DeleteByID :API
  const deleteProperty = (id) => {
    axios
      .delete(`http://localhost:8090/api/property/${id}`)
      .then((response) => response.data)
      .then((data) => {
        console.log("delete response", data);
        if (data.status == true) {
          dispatch(getPropertyList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err));
  };
useEffect(()=>{
  deleteProperty();
},[])
  return (
    <>
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Property Listing</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link href="#">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link href="#">Property Listing</Link>
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="/add-property" className="active  text-white">
                          Add Property
                        </Link>
                      </button>
                    </div>
                    <div className="card" style={{ overflowX: "auto" }}>
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr style={{ fontWeight: 700 }}>
                              <td>Id</td>
                              <td>Images</td>
                              <td>Title</td>
                              <td>Description</td>
                              <td>Category</td>
                              <td>Listed In</td>
                              <td>Price</td>
                              <td>Yearly Tax Rate</td>
                              <td>Association Fee</td>
                              <td>After Price Label</td>
                              <td>Before Price Label</td>
                              <td>Property Status</td>
                              <td>Address</td>
                              <td>State</td>
                              <td>City</td>
                              <td>Neighborhood</td>
                              <td>ZIP</td>
                              <td>Latitude</td>
                              <td>Longitude</td>
                              <td>Size (sq ft)</td>
                              <td>Lot Size (sq ft)</td>
                              <td>Rooms</td>
                              <td>Bedrooms</td>
                              <td>Bathrooms</td>
                              <td>Custom ID</td>
                              <td>Garages</td>
                              <td>Garage Size</td>
                              <td>Year Built</td>
                              <td>Available From</td>
                              <td>Basement</td>
                              <td>Extra Details</td>
                              <td>Roofing</td>
                              <td>Exterior Material</td>
                              <td>Structure Type</td>
                              <td>Floors No</td>
                              <td>Notes</td>
                              <td>Energy Class</td>
                              <td>Energy Index</td>
                              <td>Amenities</td>
                              <td>Video ID</td>
                              <td>Video Type</td>
                              <td>User Name</td>
                              <td>Updated At</td>
                              <td>Created At</td>
                              <td>Action</td>
                            </tr>
                          </thead>
                          <tbody>
                            {propertyData &&
                              propertyData.map((property) => {
                                return (
                                  <tr>
                                    <td>{propertyData.id}</td>
                                    <td>
                                      <div className="w-120px mr-4 position-relative">
                                        <a href="single-property-1.html">
                                          <img
                                            src=""
                                            alt="Home in Metric Way"
                                          />
                                          {propertyData.images}
                                        </a>
                                      </div>
                                    </td>
                                    <td>{property.title}</td>
                                    <td>{property.description}</td>
                                    <td>{property.category}</td>
                                    <td>{property.listedIn}</td>
                                    <td>{property.price}</td>
                                    <td>{property.yearlyTaxRate}</td>
                                    <td>{property.associationFee}</td>
                                    <td>{property.afterPriceLabel}</td>
                                    <td>{property.beforePriceLabel}</td>
                                    <td>{property.propertyStatus}</td>
                                    <td>{property.address}</td>
                                    <td>{property.state}</td>
                                    <td>{property.city}</td>
                                    <td>{property.neighborhood}</td>
                                    <td>{property.zip}</td>
                                    <td>{property.latitude}</td>
                                    <td>{property.longitude}</td>
                                    <td>{property.sizeInFt}</td>
                                    <td>{property.lotSizeInFt}</td>
                                    <td>{property.rooms}</td>
                                    <td>{property.bedrooms}</td>
                                    <td>{property.bathrooms}</td>
                                    <td>{property.customID}</td>
                                    <td>{property.garages}</td>
                                    <td>{property.garageSize}</td>
                                    <td>{property.yearBuilt}</td>
                                    <td>{property.availableFrom}</td>
                                    <td>{property.basement}</td>
                                    <td>{property.extraDetails}</td>
                                    <td>{property.roofing}</td>
                                    <td>{property.exteriorMaterial}</td>
                                    <td>{property.structureType}</td>
                                    <td>{property.floorsNo}</td>
                                    <td>{property.notes}</td>
                                    <td>{property.energyClass}</td>
                                    <td>{property.energyIndex}</td>
                                    <td>{property.amenities}</td>
                                    <td>{property.videoid}</td>
                                    <td>{property.videotype}</td>
                                    <td>{property.userid}</td>
                                    <td>{property.createdAt}</td>
                                    <td>{property.updatedAt}</td>
                                    <td class="d-flex">
                                      <Link
                                        to=""
                                        class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                        data-toggle="tooltip"
                                        data-placement="top"
                                        title=""
                                        data-original-title="View"
                                      >
                                        <FontAwesomeIcon
                                          icon={faEye}
                                          style={{ color: "white" }}
                                        />
                                      </Link>
                                      <Link
                                        to="/edit-property"
                                        class="btn btn-sm btn-icon float-left btn-primary me-2"
                                        data-toggle="tooltip"
                                        data-placement="top"
                                        title=""
                                        data-original-title="Edit"
                                        onClick={() =>
                                          navigateToEditProperty(property.id)
                                        }
                                      >
                                        {" "}
                                        <FontAwesomeIcon
                                          icon={faPencilSquare}
                                          style={{ color: "white" }}
                                        />
                                      </Link>
                                      <form
                                        class="float-left pl-2 me-2"
                                        action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                        method="POST"
                                      >
                                        <input
                                          type="hidden"
                                          name="_method"
                                          value="DELETE"
                                        />
                                        <input
                                          type="hidden"
                                          name="_token"
                                          value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                        />
                                        <button
                                          class="btn btn-sm btn-icon btn-danger"
                                          data-toggle="tooltip"
                                          data-placement="top"
                                          title=""
                                          data-original-title="Delete"
                                          onClick={() =>
                                            deleteProperty(property.id)
                                          }
                                        >
                                          {" "}
                                          <FontAwesomeIcon
                                            icon={faTrashAlt}
                                            style={{ color: "white" }}
                                          />
                                        </button>
                                      </form>
                                    </td>
                                  </tr>
                                );
                              })}
                          </tbody>

                          {/* <tbody>
                            <tr>
                              <td>1</td>
                              <td>
                                <div class="w-120px mr-4 position-relative">
                                  <a href="single-property-1.html">
                                    <img
                                      src="images/my-properties-01.jpg"
                                      alt="Home in Metric Way"
                                    />
                                  </a>
                                </div>
                              </td>

                              <td>Beautiful House</td>
                              <td>
                                Spacious and elegant house with modern
                                amenities.
                              </td>
                              <td>Residential</td>
                              <td>Sale</td>
                              <td>$500,000</td>
                              <td>2%</td>
                              <td>$200</td>
                              <td>Discounted Price</td>
                              <td>Original Price</td>
                              <td>Verified</td>
                              <td>123 Main St</td>
                              <td>California</td>
                              <td>Los Angeles</td>
                              <td>12345</td>
                              <td>90001</td>
                              <td>34.0522</td>
                              <td>-118.2437</td>
                              <td>2000</td>
                              <td>5000</td>
                              <td>6</td>
                              <td>4</td>
                              <td>2.5</td>
                              <td>123456</td>
                              <td>2</td>
                              <td>400</td>
                              <td>2005</td>
                              <td>0</td>
                              <td>0</td>
                              <td>Additional features and amenities.</td>
                              <td>Tile</td>
                              <td>Brick</td>
                              <td>Single Family</td>
                              <td>2</td>
                              <td>Additional notes or comments.</td>
                              <td>A</td>
                              <td>80</td>
                              <td>Swimming Pool, Gym, Garden</td>
                              <td>szvt1vD0Uug</td>
                              <td>youtube</td>
                              <td>Trupti Gaikwad</td>
                              <td>2023-07-07T11:01:48.691Z</td>
                              <td>2023-07-07T11:01:48.691Z</td>
                              <td class="d-flex">
                                <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </Link>
                                <Link
                                  to="/edit-property"
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                            <tr>
                              <td>2</td>
                              <td>
                                <div class="w-120px mr-4 position-relative">
                                  <a href="single-property-1.html">
                                    <img
                                      src="images/my-properties-02.jpg"
                                      alt="Garden Gingerbread House"
                                    />
                                  </a>
                                </div>
                              </td>
                              <td>Beautiful Apartment</td>
                              <td>
                                Spacious and elegant house with modern
                                amenities.
                              </td>
                              <td>Residential</td>
                              <td>Sale</td>
                              <td>$500,000</td>
                              <td>2%</td>
                              <td>$200</td>
                              <td>Discounted Price</td>
                              <td>Original Price</td>
                              <td>Unverified</td>
                              <td>123 Main St</td>
                              <td>California</td>
                              <td>Los Angeles</td>
                              <td>12345</td>
                              <td>90001</td>
                              <td>34.0522</td>
                              <td>-118.2437</td>
                              <td>2000</td>
                              <td>5000</td>
                              <td>6</td>
                              <td>4</td>
                              <td>2.5</td>
                              <td>123456</td>
                              <td>2</td>
                              <td>400</td>
                              <td>2005</td>
                              <td>0</td>
                              <td>0</td>
                              <td>Additional features and amenities.</td>
                              <td>Tile</td>
                              <td>Brick</td>
                              <td>Single Family</td>
                              <td>2</td>
                              <td>Additional notes or comments.</td>
                              <td>A</td>
                              <td>80</td>
                              <td>Swimming Pool, Gym, Garden</td>
                              <td>szvt1vD0Uug</td>
                              <td>youtube</td>
                              <td>Mrinal Sharma</td>
                              <td>2023-07-07T11:01:48.691Z</td>
                              <td>2023-07-07T11:01:48.691Z</td>
                              <td class="d-flex">
                                <Link
                                  to=""
                                  class="btn btn-sm btn-icon me-2
                                                              float-left btn-info"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="View"
                                >
                                  <FontAwesomeIcon
                                    icon={faEye}
                                    style={{ color: "white" }}
                                  />
                                </Link>
                                <Link
                                  to="/edit-property"
                                  class="btn btn-sm btn-icon float-left btn-primary me-2"
                                  data-toggle="tooltip"
                                  data-placement="top"
                                  title=""
                                  data-original-title="Edit"
                                >
                                  {" "}
                                  <FontAwesomeIcon
                                    icon={faPencilSquare}
                                    style={{ color: "white" }}
                                  />
                                </Link>
                                <form
                                  class="float-left pl-2 me-2"
                                  action="https://fit-buddy.io/admin/admin/menu-items/1615"
                                  method="POST"
                                >
                                  <input
                                    type="hidden"
                                    name="_method"
                                    value="DELETE"
                                  />
                                  <input
                                    type="hidden"
                                    name="_token"
                                    value="C4KWMkgrCT3CJNo8uJLXYiLCgDcL5LvFf7KFfBul"
                                  />
                                  <button
                                    class="btn btn-sm btn-icon btn-danger"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="Delete"
                                  >
                                    {" "}
                                    <FontAwesomeIcon
                                      icon={faTrashAlt}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </form>
                              </td>
                            </tr>
                          </tbody> */}
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
    </>
  );
};

export default PropertyListing;
