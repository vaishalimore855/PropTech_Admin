import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { getBuyerbyId } from "../../../../Redux/Slice/BuyerSlice";

function PersonalDetailsBuyer() {
  const { id } = useParams();
  const dispatch = useDispatch();
  const Buyer = useSelector((state) => state.buyer.Buyer);

  console.log("view buyer", JSON.stringify(Buyer));

  useEffect(() => {
    dispatch(getBuyerbyId(id));
  }, [id]);

  return (
    
    <>
      <div className="view-document-main col-lg-6" style={{marginLeft:"10%"}}>
        <dl className="row ">
          <dt className="col-5">Name:</dt>
          <dd className="col-7">{Buyer?.personaldata?.fullname}</dd>
        </dl>
        <dl className="row ">
          <dt className="col-5">Contact Number:</dt>
          <dd className="col-7">{Buyer?.personaldata?.phoneNumber}</dd>
        </dl>
        <dl className="row ">
          <dt className="col-5">Email ID:</dt>
          <dd className="col-7">{Buyer?.personaldata?.email}</dd>
        </dl>
        <dl className="row ">
          <dt className="col-5">User Role</dt>
          <dd className="col-7">{Buyer?.personaldata?.userrole}</dd>
        </dl>

        <dl className="row ">
          <dt className="col-5">Address:</dt>
          <dd className="col-7">{Buyer?.personaldata?.address}</dd>
        </dl>
        <dl className="row ">
          <dt className="col-5">Verification Status:</dt>
          <dd className="col-7">
            {Buyer?.personaldata?.isVerifiedByAdmin == false ? (
              <span
                style={{
                  color: "red",
                  border: "1px solid red",
                  padding: "4 4",
                  borderRadius: 14,
                }}
              >
                Not Verified
              </span>
            ) : (
              <span
                style={{
                  color: "green",
                  border: "1px solid green",
                  padding: "6 6",
                  borderRadius: 14,
                }}
              >
                {" "}
                Verified
              </span>
            )}
          </dd>
        </dl>
      </div>
    </>
  );
}

export default PersonalDetailsBuyer;
