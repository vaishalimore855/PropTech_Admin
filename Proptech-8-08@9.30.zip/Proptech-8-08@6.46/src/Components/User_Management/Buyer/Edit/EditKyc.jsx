import React, { useState,useRef, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {getKycBuyerUserid } from "../../../../Redux/Slice/BuyerSlice";
import { useNavigate } from "react-router-dom";

const EditKyc = () => {

  const getUserId = localStorage.getItem("userId");
  var navigate = useNavigate();
  const { id } = useParams();
  const adharFrontRef = useRef(null);
  const adharBackRef = useRef(null);
  const panCardRef = useRef(null);
  const [userId, setUserId] = useState(""); // Set the user ID here
  console.log("userId", userId);
  const dispatch = useDispatch();
  const kycuserId = useSelector((state) => state.buyer.KycUserid);
  console.log("kycuserId .......", JSON.stringify(kycuserId));

  const [editedKycBuyer, setEditedKycBuyer] = useState({
    adharBack:"",
    adharFront:"",
    panCard:"",
    userId:"",
  });
  useEffect(() => {
    dispatch(getKycBuyerUserid(getUserId));
  }, [getUserId]);

  useEffect(() => {
    setEditedKycBuyer({
      adharFront:kycuserId?.adharFront,
      adharBack:kycuserId?.adharBack,
      panCard:kycuserId?.pan,
      userid:kycuserId?.userid
    });
  }, [kycuserId]);


  const handleFileChange = (event, inputName) => {
    const file = event.target.files[0];

    if (file) {
      setEditedKycBuyer((prevSelectedFiles) => ({
        ...prevSelectedFiles,
        [inputName]: file,
      }));
    }
  };


  const handleEditKycProfile = (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedKycBuyer),
      headers: {
        "Content-type": "application/json",
      },
    };

    fetch(`http://65.20.73.28:8090/api/profile/${userId}`, data)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/buyer");
      })
      .catch((err) => console.log(err));
  };

  return (
   <>
    {/* <ToastContainer /> */}
    <form
      style={{ height: "auto" }}
      // onSubmit={handleSubmit}
    >
      <div className="row">
        <div className="col-md-6 mb-3">
          {editedKycBuyer && (
            <div>
              <img
                src={(editedKycBuyer.aadhar_front_base64)}
                alt="Adhar Front"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )}

          <label for="validationCustom01">Aadhar Front </label>

          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={adharFrontRef}
            onChange={(event) => handleFileChange(event, "adharBack")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => adharFrontRef.current.click()}
          >
            Add Adhar Front
          </button>
        </div>
        <div className="col-md-6 mb-3">
          {editedKycBuyer && (
            <div>
              <img
                src={(editedKycBuyer.aadhar_back_base64)}
                alt="Adhar Back"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )}
          <label for="validationCustom04">Aadhar front</label>

          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={adharBackRef}
            onChange={(event) => handleFileChange(event, "adharBack")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => adharBackRef.current.click()}
          >
            Add Adhar Back
          </button>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6 mb-3">
          {editedKycBuyer && (
            <div>
              <img
                src={editedKycBuyer.pan_base64}
                alt="Adhar Back"
                style={{ width: "200px", height: "200px" }}
              />
            </div>
          )}
          <label for="validationCustom04">Pan</label>
          <input
            className="form-control"
            type="file"
            accept="image/*"
            ref={panCardRef}
            onChange={(event) => handleFileChange(event, "panCard")}
          />
          <button
            style={{ display: "none" }}
            onClick={() => panCardRef.current.click()}
          >
            Add Pan Card
          </button>{" "}
        </div>

        <div className="col-md-6 mb-3">
          <label for="validationCustom04">User Id</label>
          <input
            className="form-control"
            type="text"
            value={getUserId}
            // onChange={(e) => setUserId(e.target.value)}
            placeholder="Enter User ID"
          />
        </div>
      </div>

      <button
        className="btn btn-primary mt-2"
        type="submit"
        onClick={() => handleEditKycProfile()}
      >
        Submit
      </button>
    </form>
  </>
  );
};

export default EditKyc;
