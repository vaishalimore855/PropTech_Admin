import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getBuyerbyId } from "../../../../Redux/Slice/BuyerSlice";
import { useNavigate } from "react-router-dom";

const EditBuyerPersonalDetails = () => {
  var navigate = useNavigate();
  const { id } = useParams();

  const dispatch = useDispatch();
  const BuyerId = useSelector((state) => state.buyer.Buyer);
  console.log("buyerId .......", JSON.stringify(BuyerId));

  const [editedBuyer, setEditedBuyer] = useState({
    fullname: "",
    email: "",
    phoneNumber: "",
    userrole: "Buyer",
    mobileverified: true,
    password: "",
  });
  useEffect(() => {
    dispatch(getBuyerbyId(id));
  }, [id]);

  useEffect(() => {
    setEditedBuyer({
      fullname: BuyerId?.personaldata?.fullname,
      email: BuyerId?.personaldata?.email,
      phoneNumber: BuyerId?.personaldata?.phoneNumber,
      userrole: BuyerId?.personaldata?.userrole,
      mobileverified: BuyerId?.personaldata?.mobileverified,
      password: "",
    });
  }, [BuyerId]);

  const handleChangeEditBuyerInput = (e) => {
    const { name, value } = e.target;
    setEditedBuyer({
      ...editedBuyer,
      [name]: value,
    });
  };

  const handleEditProfile = (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedBuyer),
      headers: {
        "Content-type": "application/json",
      },
    };

    fetch(`http://65.20.73.28:8090/api/users/${id}`, data)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/buyer");
      })
      .catch((err) => console.log(err));
  };

  return (
    <>
      <ToastContainer />
      <form>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Full Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your full Name"
              name="fullname"
              
              value={editedBuyer.fullname}
              onChange={(e) => handleChangeEditBuyerInput(e)}
            />

            <div className="valid-feedback">Looks good!</div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={editedBuyer.phoneNumber}
              onChange={(e) => handleChangeEditBuyerInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid phone Number.
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="text"
              className="form-control"
              placeholder=" Enter City"
              name="email"
              value={editedBuyer.email}
              onChange={(e) => handleChangeEditBuyerInput(e)}
            />
            <div className="invalid-feedback"></div>
          </div>

          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={editedBuyer.password}
              onChange={(e) => handleChangeEditBuyerInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid location.
            </div>
          </div>
          
        </div>
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={(e) => handleEditProfile(e)}
        >
          Submit{" "}
        </button>
      </form>
    </>
  );
};

export default EditBuyerPersonalDetails;
