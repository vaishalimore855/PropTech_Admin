import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { getAdminMenuList, getAdminMenuId } from "../../Redux/Slice/MenuSlice";
import { useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { Button, Modal, Paper } from "@mui/material";
import * as ExcelJS from "exceljs";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  modalPaper: {
    position: "absolute",
    top: "20%",
    left: "50%",
    transform: "translate(-50%, -20%)",
    width: 350,
    height: 100,
    paddingLeft: "30px",
    // padding: theme.spacing(2, 4, 3),
  },
}));
function AdminMenu() {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { id } = useParams();
  const token = localStorage.getItem("token");
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);

  const AdminMenuList = useSelector((state) => state.adminMenu.AdminMenuList);
  var navigate = useNavigate();

  useEffect(() => {
    dispatch(getAdminMenuList());
    getAdminMenuId(id);
  }, []);

  //Excel Data
  const exportToExcel = () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Data");

    // Add headers
    const headers = [
      "Id",
      " Title",
      "Path",
      "Icon",
      "Priority",
      "Parentid",
      "SubNav",
    ]; // Fixed header names
    worksheet.addRow(headers);

    // Add data rows
    AdminMenuList.forEach((row) => {
      worksheet.addRow([
        row.id,
        row.title,
        row.path,
        row.icon,
        row.priority,
        row.parentid,
        row.subNav,
      ]); // Fixed field names
    });

    // Generate Excel file
    workbook.xlsx.writeBuffer().then((buffer) => {
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "data.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    });
  };
  const navigateToEditAdminMenu = (id) => {
    navigate(`/edit-adminmenu/${id}`);
  };

  const confirmDelete = (id) => {
    setItemToDelete(id);
    setOpenConfirmation(true);
  };

  const cancelDelete = () => {
    setItemToDelete(null);
    setOpenConfirmation(false);
  };

  const executeDelete = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/adminmenus/${id}`, {
        headers: {
          authorization: token,
        },
      })
      .then((response) => response.data)
      .then((data) => {
        if (data.status !== true) {
          dispatch(getAdminMenuList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err))
      .finally(() => {
        setItemToDelete(null);
        setOpenConfirmation(false);
      });
  };

  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            <div className="page-header mt-5">
              <h4>Admin Menu</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/Dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Admin Menu
                  </li>
                </ol>
              </nav>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body" style={{ height: "200%" }}>
                    <div className="pt-4 pb-4 text-left justify-content-between">
                      <div className="row">
                        <div className="d-flex justify-content-between">
                          <button className="btn btn-primary btn-rounded">
                            <Link to="/AddMenu" className="text-white">
                              + Add
                            </Link>
                          </button>

                          <Button
                            onClick={exportToExcel}
                            enabled={!AdminMenuList.length}
                            variant="contained"
                            style={{
                              backgroundColor: "#3A833A",
                              marginRight: "10px",
                            }}
                          >
                            Export to Excel
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Title</th>
                              <th>Icon</th>
                              <th>ParentId</th>
                              <th>Path</th>
                              <th>Priority</th>
                              <th>subNav</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {AdminMenuList &&
                              AdminMenuList.map((menu) => (
                                <tr key={menu.id}>
                                  <td>{menu.title}</td>
                                  <td>{menu.icon}</td>
                                  <td>{menu.parentid}</td>
                                  <td>{menu.path}</td>
                                  <td>{menu.priority}</td>
                                  <td>{menu.subNav}</td>
                                  <td className="d-flex justify-content-center align-items-center">
                                    <button
                                      onClick={() =>
                                        navigateToEditAdminMenu(menu.id)
                                      }
                                      className="btn btn-sm btn-icon me-2 float-left btn-primary"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Edit"
                                    >
                                      <FontAwesomeIcon
                                        icon={faPencilSquare}
                                        style={{ color: "white" }}
                                      />
                                    </button>

                                    <button
                                      className="btn btn-sm btn-icon me-2 btn-danger"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Delete"
                                      onClick={() => confirmDelete(menu.id)}
                                    >
                                      <FontAwesomeIcon
                                        icon={faTrashAlt}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                          <Modal open={openConfirmation} onClose={cancelDelete}>
                            <Paper className={classes.modalPaper}>
                              <div className="confirmation-modal">
                                <div className="confirmation-content">
                                  <p style={{ marginTop: "10px" }}>
                                    Are you sure you want to delete this item?
                                  </p>
                                  <div className="row">
                                    <div className="col-md-5">
                                      <Button
                                        className="btn btn-primary text-white "
                                        style={{ marginLeft: "30px" }}
                                        onClick={() =>
                                          executeDelete(itemToDelete)
                                        }
                                      >
                                        Confirm
                                      </Button>
                                    </div>
                                    <div className="col-md-5">
                                      <Button
                                        className="btn btn-primary text-white"
                                        onClick={cancelDelete}
                                      >
                                        Cancel
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </Paper>
                          </Modal>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminMenu;
