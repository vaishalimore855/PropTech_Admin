import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getAdminMenuId } from "../../Redux/Slice/MenuSlice";
import { useNavigate } from "react-router-dom";

const EditAdminMenu = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();
  const adminMenuId = useSelector((state) => state.adminMenu.AdminMenuId);

  const [editedAdminmenu, setEditedAdminmenu] = useState({
    name: "",
    icon: "",
    link: "",
    priority: "",
    parentid: "",
    type: "",
  });

  useEffect(() => {
    dispatch(getAdminMenuId(id));
  }, [dispatch, id]);

  useEffect(() => {
    if (adminMenuId) {
      setEditedAdminmenu({
        name: adminMenuId.name,
        icon: adminMenuId.icon,
        link: adminMenuId.link,
        priority: adminMenuId.priority,
        parentid: adminMenuId.parentid,
        type: adminMenuId.type,
      });
    }
  }, [adminMenuId]);

  const handleChangeEditAdminmenuInput = (e) => {
    const { name, value } = e.target;
    setEditedAdminmenu((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleEditAdminmenu = async (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedAdminmenu),
      headers: {
        "Content-Type": "application/json",
        authorization: token,
      },
    };

    try {
      const response = await fetch(
        `http://65.20.73.28:8090/api/adminmenus/${id}`,
        data
      )
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/adminmenu");
      })
     
    } catch (error) {
      console.error("Error updating admin menu:", error);
      toast.error("An error occurred while updating the admin menu.");
    }
  };


 
  return (
    <div>
      <div id="main">
        <div className="main-content">
          <div className="container">
            <ToastContainer />
            <div className="page-header mt-5">
              <h4>Edit Admin Menu</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Privilege</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="/AdminMenu">Edit Admin Menu</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Edit Menu
                  </li>
                </ol>
              </nav>
            </div>
            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <form>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom01"> Name </label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Your Name"
                            name="name"
                            value={editedAdminmenu.name}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom02">Link</label>
                          <input
                            type="text"
                            data-input-mask="phone"
                            className="form-control"
                            placeholder="Enter Path"
                            name="link"
                            value={editedAdminmenu.link}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Icon</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Icon"
                            name="icon"
                            value={editedAdminmenu.icon}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>

                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Parent Id</label>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="Enter Menu Id"
                            name="parentid"
                            value={editedAdminmenu.parentid}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Priority</label>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="Enter priority for menu item"
                            name="priority"
                            value={editedAdminmenu.priority}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Type</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Menu Type"
                            name="type"
                            value={editedAdminmenu.type}
                            onChange={(e) => handleChangeEditAdminmenuInput(e)}
                          />
                        </div>
                      </div>
                      <button
                        className="btn btn-primary mt-2"
                        type="submit"
                        onClick={handleEditAdminmenu}
                      >
                        Submit
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditAdminMenu;
