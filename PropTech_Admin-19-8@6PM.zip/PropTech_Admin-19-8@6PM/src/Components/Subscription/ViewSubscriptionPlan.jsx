
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useSelector, useDispatch } from "react-redux";
import { getSubscriptionbyId } from "../../Redux/Slice/SubscriptionSlice";
import "react-toastify/dist/ReactToastify.css";
import { useParams } from "react-router-dom";
import Stack from "@mui/material/Stack";
import { Button, Modal, Box, TextField } from '@mui/material';
import { ToastContainer, toast } from "react-toastify";
import { Link, useNavigate } from 'react-router-dom';

const ViewPropertyVerification = () => {
  var navigate = useNavigate();
  const { id } = useParams();
  const dispatch = useDispatch();
  const Subscription = useSelector((state) => state.SubscriptionData.Subscription);
  const [currentTab, setCurrentTab] = useState(0);
  const handleChangeTab = (event, newValue) => {
    setCurrentTab(newValue);
  };
  useEffect(() => {
    dispatch(getSubscriptionbyId(id));
  }, [id]);

  const token = localStorage.getItem("token");
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);


  const subscriptionValues = {
    name: "",
    price: "",
    feature: "",
    status: "",
  };

  const [subscription, setsubscription] = useState(subscriptionValues);

  useEffect(() => {
    setsubscription({
      name: Subscription?.name,
      price: Subscription?.price,
      feature: Subscription?.feature,
      status: Subscription?.status
    });
  }, [Subscription]);


  const handleChangeAddsubscriptionInput = (e) => {
    const { name, value } = e.target;
    setsubscription({
      ...subscription,
      [name]: value,
    });
  };


  const validate = (subscription) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!subscription.name) {
      errors.name = "Plan name cannot be blank";
    } else if (!subscription.price) {
      errors.price = "Price cannot be blank";
    } else if (!subscription.feature) {
      errors.feature = "Feature cannot be blank";
    } else if (!subscription.status) {
      errors.status = "Status cannot be blank";
    }

    return errors;
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4> View Subscription Plan</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Subscription Plan</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    View Property Management Screen
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left"></div>
                    <div className="card">
                      <div className="card-body">
                        <div className="view-document-main col-lg-12">
                          <div className="view-document-main col-lg-12" style={{ padding: "3%" }}>
                            <div class="row">
                              <div class="col-8">
                                <dl className="row ">
                                  <dt className="col-5">Plan Name:</dt>
                                  <dd className="col-7">{subscription?.name}</dd>
                                </dl>
                                <dl className="row ">
                                  <dt className="col-5">Price:</dt>
                                  <dd className="col-7">{subscription?.price}</dd>
                                </dl>
                                <dl className="row ">
                                  <dt className="col-5">Feature:</dt>
                                  <dd className="col-7">{subscription?.feature}</dd>
                                </dl>
                                <dl className="row ">
                                  <dt className="col-5">Status</dt>
                                  <dd className="col-7">{subscription?.status}</dd>
                                </dl>
                              </div>

                            </div>

                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default ViewPropertyVerification;
