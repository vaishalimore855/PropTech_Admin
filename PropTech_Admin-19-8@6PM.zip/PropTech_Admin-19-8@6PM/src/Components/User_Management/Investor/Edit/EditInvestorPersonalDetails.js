import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getInvestorById } from "../../../../Redux/Slice/InvestorSlice";
import { useNavigate } from "react-router-dom";

const EditInvestorPersonalDetails = () => {
  var navigate = useNavigate();
  const { id } = useParams();
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();
  const investorId = useSelector((state) => state.investor.Investor);
  console.log("investorId .......", JSON.stringify(investorId));

  const [editedInvestor, setEditedInvestor] = useState({
    firstname: "",
    lastname:"",
    email: "",
    phoneNumber: "",
    userrole: "investor",
    mobileverified: true,
    password: "",
  });
  useEffect(() => {
    dispatch(getInvestorById(id));
  }, [id]);

  useEffect(() => {
    setEditedInvestor({
      // fullname: investorId?.personaldata?.fullname,
      firstname: investorId?.personaldata?.firstname,
      lastname: investorId?.personaldata?.lastname,
      email: investorId?.personaldata?.email,
      phoneNumber: investorId?.personaldata?.phoneNumber,
      userrole: investorId?.personaldata?.userrole,
      mobileverified: investorId?.personaldata?.mobileverified,
      password: "",
    });
  }, [investorId]);

  const handleChangeEditInvestorInput = (e) => {
    const { name, value } = e.target;
    setEditedInvestor({
      ...editedInvestor,
      [name]: value,
    });
  };

  const handleEditProfile = (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedInvestor),
      headers: {
         "Content-Type": "application/json",
        "authorization":token
      },
    };

    fetch(`http://65.20.73.28:8090/api/users/${id}`, data)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/investor");
      })
      .catch((err) => console.log(err));
  };

  return (
    <>
      <ToastContainer />
      {/* <form>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Full Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your full Name"
              name="fullname"
              
              value={editedInvestor.fullname}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />

            <div className="valid-feedback">Looks good!</div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={editedInvestor.phoneNumber}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid phone Number.
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="text"
              className="form-control"
              placeholder=" Enter City"
              name="email"
              value={editedInvestor.email}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback"></div>
          </div>

          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={editedInvestor.password}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid location.
            </div>
          </div>
                 </div>
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={(e) => handleEditProfile(e)}
        >
          Submit{" "}
        </button>
      </form> */}

      <form>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">First Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your first Name"
              name="firstname"
              
              value={editedInvestor.firstname}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />

            <div className="valid-feedback">Looks good!</div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Last Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your last Name"
              name="lastname"
              
              value={editedInvestor.lastname}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />

            <div className="valid-feedback">Looks good!</div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={editedInvestor.phoneNumber}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid phone Number.
            </div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="text"
              className="form-control"
              placeholder=" Enter City"
              name="email"
              value={editedInvestor.email}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback"></div>
          </div>

        </div>
        <div className="row mt-3">
          
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={editedInvestor.password}
              onChange={(e) => handleChangeEditInvestorInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid location.
            </div>
          </div>
          
        </div>
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={(e) => handleEditProfile(e)}
        >
          Submit{" "}
        </button>
      </form>
    </>
  );
};

export default EditInvestorPersonalDetails;
