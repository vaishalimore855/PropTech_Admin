import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { useSelector, useDispatch } from "react-redux";
import { getPropertybyId } from "../../../Redux/Slice/PropertyListingSlice";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useParams } from "react-router-dom";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";

const ViewPropertyListing = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPropertybyId(id));
  }, [dispatch, id]);

  const PropertyListingId = useSelector(
    (state) => state.propertylisting.property
  );

  console.log("PropertyListingId", PropertyListingId[0]);

  const token = localStorage.getItem("token");
  //carousel
  const [images, setImages] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    // Fetch images from the API here
    setImages(`${PropertyListingId[0]?.mediaData?.images}`);
    console.log("images", images);
  }, []);

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4> View Property Listing</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Property Listing Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    View Property Listing
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left"></div>

                    <div className="view-document-main col-lg-12">
                      <Grid
                        container
                        rowSpacing={1}
                        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      >
                        <Grid item xs={12}>
                          {/* {PropertyListingId[0]?.mediaData?.images ? (
                            <div
                              className="col-md-12 d-flex justify-content-center align-items-center"
                              style={{
                                width: "400px",
                                height: "300px",
                                border: "1px black solid",
                                padding: "10px",
                                marginRight: "20px",
                                borderRadius: "10px",
                              }}
                            >
                              <img
                                src={`data:image/png;base64,${PropertyListingId[0]?.mediaData?.images}`}
                                alt=""
                                width="80%"
                                height="102%"
                              />
                            </div>
                          ) : (
                            <div>No Media Image</div>
                          )} */}
                          <div className="carousel col-md-12 d-flex justify-content-center align-items-center"
                          style={{height:"300px",width:"100%"}}
                          >
                            <span
                              className="carousel-btn"
                              onClick={prevImage}
                              style={{fontSize:"40px",marginRight:"20%"}}

                            >
                              &lt; 
                            </span>
                            {images.length > 0 && (
                              <img
                                height="290px"
                                width="30%"
                                className="carousel-image mb-5"
                                src={`data:image/png;base64,${PropertyListingId[0]?.mediaData?.images}`}
                                alt={`Image ${currentImageIndex}`}
                              />
                            )}
                            <span
                              className="carousel-btn "
                              onClick={nextImage}
                              style={{fontSize:"40px",marginLeft:"20%"}}
                            >
                               &gt;
                            </span>
                          </div>
                        </Grid>
                      </Grid>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="card-body">
                    <div className="pt-2 pb-4 text-left">
                      <h4>Property Data</h4>
                    </div>
                    <div className="view-document-main col-lg-12">
                      <Grid
                        container
                        rowSpacing={1}
                        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      >
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Id:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.id}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Title:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.title}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Description:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.description
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Category:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.category}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Subcategory:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.subcategory
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">ListedIn:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.listedIn}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Price:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.price}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">YearlyTaxRate:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.yearlyTaxRate
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">AssociationFee:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.associationFee
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">AfterPriceLabel:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.afterPriceLabel
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">BeforePriceLabel:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.beforePriceLabel
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">PropertyStatus:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.propertyStatus
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">RejectReason:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.rejectReason
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Userid:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.userid}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Propertymanagerid:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.propertymanagerid
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Agentid:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.propertydata?.agentid}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">CreatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.createdAt
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">UpdatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.propertydata
                                      ?.updatedAt
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                      </Grid>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="card-body">
                    <div className="pt-2 pb-4 text-left">
                      <h4>Location Details</h4>
                    </div>
                    <div className="view-document-main col-lg-12">
                      <Grid
                        container
                        rowSpacing={1}
                        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      >
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Id:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.id}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Address:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.address}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">State:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.state}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">City:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.city}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Country:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.country}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Neighborhood:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.neighborhood
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Zip:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.zip}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Latitude:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.latitude}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Longitude:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.longitude
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Propertyid:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.propertyid
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">CreatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.createdAt
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">UpdatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.updatedAt
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                      </Grid>
                    </div>
                  </div>
                </div>
                <div className="card">
                  <div className="card-body">
                    <div className="pt-2 pb-4 text-left">
                      <h4> Details Data</h4>
                    </div>
                    <div className="view-document-main col-lg-12">
                      <Grid
                        container
                        rowSpacing={1}
                        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      >
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Id:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.id}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">SizeInFt:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.sizeInFt}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">LotSizeInFt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.lotSizeInFt
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Rooms:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.rooms}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Bedrooms:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.bedrooms}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Bathrooms:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.bathrooms}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">CustomID:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.customID}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Garages:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.garages}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">GarageSize:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.garageSize
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">YearBuilt:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.yearBuilt}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">CreatedAt:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.createdAt}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">UpdatedAt:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.updatedAt}
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">AvailableFrom:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.availableFrom
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Basement:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.basement}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">ExtraDetails:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.extraDetails
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Roofing:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.roofing}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">ExteriorMaterial:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.exteriorMaterial
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">StructureType:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.structureType
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">FloorsNo:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.floorsNo}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Notes:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.detailsData?.notes}
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">emailnergyClass:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.energyClass
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">EnergyIndex:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.energyIndex
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">Propertyid:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.detailsData
                                      ?.propertyid
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                      </Grid>
                    </div>
                  </div>
                </div>

                <div className="card">
                  <div className="card-body">
                    <div className="pt-2 pb-4 text-left">
                      <h4>Amenities & Media Details</h4>{" "}
                    </div>
                    <div className="view-document-main col-lg-12">
                      <Grid
                        container
                        rowSpacing={1}
                        columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      >
                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Amenities:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.amenitiesData
                                      ?.amenities
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Id:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.locationData?.id}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Propertyid:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.propertyid
                                  }
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">CreatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.locationData
                                      ?.createdAt
                                  }
                                </dd>
                              </dl>

                              <dl className="row ">
                                <dt className="col-5">UpdatedAt:</dt>
                                <dd className="col-7">
                                  {
                                    PropertyListingId[0]?.amenitiesData
                                      ?.updatedAt
                                  }
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>

                        <Grid item xs={6}>
                          <div class="row">
                            <div class="col-12">
                              <dl className="row ">
                                <dt className="col-5">Videoid:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.mediaData?.videoid}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Videotype:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.mediaData?.videotype}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Virtualtour:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.mediaData?.virtualtour}
                                </dd>
                              </dl>
                              <dl className="row ">
                                <dt className="col-5">Propertyid:</dt>
                                <dd className="col-7">
                                  {PropertyListingId[0]?.mediaData?.propertyid}
                                </dd>
                              </dl>
                            </div>
                          </div>
                        </Grid>
                      </Grid>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>

      {/* <!-- end::main --> */}
    </div>
  );
};

export default ViewPropertyListing;