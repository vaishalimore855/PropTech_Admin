import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { useSelector, useDispatch } from "react-redux";
import {
  getPropertyList,
  getPropertybyId,
} from "../../../Redux/Slice/PropertyListingSlice";
import axios from "axios";
import * as ExcelJS from "exceljs";
import { ToastContainer, toast } from "react-toastify";
import { Button, Modal, Paper } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  modalPaper: {
    position: "absolute",
    top: "20%",
    left: "50%",
    transform: "translate(-50%, -20%)",
    width: 350,
    height: 100,
    paddingLeft: "30px",
    // padding: theme.spacing(2, 4, 3),
  },
}));

const PropertyListing = () => {
  const { id } = useParams();
  //property list
  const dispatch = useDispatch();
  const classes = useStyles();
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);

  const PropertyList = useSelector(
    (state) => state.propertylisting.propertyListingList
  );
  console.log("PropertyList", PropertyList);

  useEffect(() => {
    dispatch(getPropertyList(id));
  }, []);

  //property Id
  const PropertyId = useSelector((state) => state.propertylisting.property);
  console.log("PropertyId", PropertyId);

  useEffect(() => {
    dispatch(getPropertybyId());
  }, []);

  //Excel Data
  const exportToExcel = () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Data");

    // Add headers
    const headers = [
      "Id",
      " Title",
      "Path",
      "Icon",
      "Priority",
      "Parentid",
      "SubNav",
    ]; // Fixed header names
    worksheet.addRow(headers);

    // Add data rows
    PropertyList.forEach((row) => {
      worksheet.addRow([
        row.id,
        row.title,
        row.path,
        row.icon,
        row.priority,
        row.parentid,
        row.subNav,
      ]); // Fixed field names
    });

    // Generate Excel file
    workbook.xlsx.writeBuffer().then((buffer) => {
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "data.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    });
  };
  var navigate = useNavigate();
  const navigateToViewPropertyListing = (id) => {
    navigate(`/view-propertylisting/${id}`);
  };
  const navigateToEditProperty = (id) => {
    navigate(`/edit-property/${id}`);
  };

  const confirmDelete = (id) => {
    setItemToDelete(id);
    setOpenConfirmation(true);
  };
  const token = localStorage.getItem("token");

  const cancelDelete = () => {
    setItemToDelete(null);
    setOpenConfirmation(false);
  };

  const executeDelete = (id) => {
    axios
      .delete(`http://65.20.73.28:8090//api/property/${id}`, {
        headers: {
          authorization: token,
        },
      })
      .then((response) => response.data)
      .then((data) => {
        if (data.status !== true) {
          dispatch(getPropertyList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err))
      .finally(() => {
        setItemToDelete(null);
        setOpenConfirmation(false);
      });
  };

  return (
    <>
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Property Listing</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link href="#">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link href="#">Property Listing</Link>
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="row">
                      <div className="d-flex justify-content-end">
                        <Button
                          onClick={exportToExcel}
                          enabled={!PropertyList.length}
                          variant="contained"
                          style={{
                            backgroundColor: "#3A833A",
                            marginRight: "10px",
                          }}
                        >
                          Export to Excel
                        </Button>
                      </div>
                    </div>

                    <div className="card" style={{ overflowX: "auto" }}>
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr style={{ fontWeight: 700 }}>
                              <td>Id</td>
                              <td>Image</td>
                              <td>Title</td>
                              <td>Description</td>
                              <td>Category</td>
                              <td>Listed In</td>
                              <td>Price</td>
                              <td>Yearly Tax Rate</td>
                              <td>Association Fee</td>
                              <td>After Price Label</td>
                              <td>Before Price Label</td>
                              <td>Property Status</td>
                              <td>Address</td>
                              <td>State</td>
                              <td>City</td>
                              <td>Neighborhood</td>
                              <td>ZIP</td>
                              <td>Latitude</td>
                              <td>Longitude</td>
                              <td>Size (sq ft)</td>
                              <td>Lot Size (sq ft)</td>
                              <td>Rooms</td>
                              <td>Bedrooms</td>
                              <td>Bathrooms</td>
                              <td>Custom ID</td>
                              <td>Garages</td>
                              <td>Garage Size</td>
                              <td>Year Built</td>
                              <td>Available From</td>
                              <td>Basement</td>
                              <td>Extra Details</td>
                              <td>Roofing</td>
                              <td>Exterior Material</td>
                              <td>Structure Type</td>
                              <td>Floors No</td>
                              <td>Notes</td>
                              <td>Energy Class</td>
                              <td>Energy Index</td>
                              <td>Amenities</td>
                              <td>Video ID</td>
                              <td>Video Type</td>

                              <td>Updated At</td>
                              <td>Created At</td>
                              <td>Action</td>
                            </tr>
                          </thead>
                          <tbody>
                            {PropertyList &&
                              PropertyList.map((property, index) => {
                                return (
                                  <tr>
                                    <td>{index + 1}</td>
                                    <td>
                                      <div className="d-flex justify-content-center align-items-center">
                                        <img
                                          src={property?.mediaData?.images}
                                          alt=""
                                          width="100%"
                                          height="100%"
                                        />
                                      </div>
                                    </td>
                                    <td>{property?.propertydata?.title}</td>
                                    <td>
                                      {property?.propertydata?.description}
                                    </td>
                                    <td>{property?.propertydata?.category}</td>

                                    <td>{property?.propertydata?.listedIn}</td>
                                    <td>{property?.propertydata?.price}</td>
                                    <td>
                                      {property?.propertydata?.yearlyTaxRate}
                                    </td>
                                    <td>
                                      {property?.propertydata?.associationFee}
                                    </td>
                                    <td>
                                      {property?.propertydata?.afterPriceLabel}
                                    </td>
                                    <td>
                                      {property?.propertydata?.beforePriceLabel}
                                    </td>
                                    <td>
                                      {property?.propertydata?.propertyStatus}
                                    </td>
                                    <td>{property?.locationData?.address}</td>
                                    <td>{property?.locationData?.state}</td>
                                    <td>{property?.locationData?.city}</td>
                                    <td>
                                      {property?.locationData?.neighborhood}
                                    </td>
                                    <td>{property?.locationData?.zip}</td>
                                    <td>{property?.locationData?.latitude}</td>
                                    <td>{property?.locationData?.longitude}</td>

                                    <td>{property?.detailsData?.sizeInFt}</td>
                                    <td>
                                      {property?.detailsData?.lotSizeInFt}
                                    </td>
                                    <td>{property?.detailsData?.rooms}</td>
                                    <td>{property?.detailsData?.bedrooms}</td>
                                    <td>{property?.detailsData?.bathrooms}</td>
                                    <td>{property?.detailsData?.customID}</td>
                                    <td>{property?.detailsData?.garages}</td>
                                    <td>{property?.detailsData?.garageSize}</td>
                                    <td>{property?.detailsData?.yearBuilt}</td>
                                    <td>
                                      {property?.detailsData?.availableFrom}
                                    </td>
                                    <td>{property?.detailsData?.basement}</td>

                                    <td>
                                      {property?.detailsData?.extraDetails}
                                    </td>
                                    <td>{property?.detailsData?.roofing}</td>
                                    <td>
                                      {property?.detailsData?.exteriorMaterial}
                                    </td>
                                    <td>
                                      {property?.detailsData?.structureType}
                                    </td>
                                    <td>{property?.detailsData?.floorsNo}</td>

                                    <td>{property?.detailsData?.notes}</td>
                                    <td>
                                      {property?.detailsData?.energyClass}
                                    </td>
                                    <td>
                                      {property?.detailsData?.energyIndex}
                                    </td>

                                    <td>
                                      {property?.amenitiesData?.amenities}
                                    </td>
                                    <td>{property?.mediaData?.videoid}</td>
                                    <td>{property?.mediaData?.videotype}</td>
                                    <td>
                                      {property?.amenitiesData?.updatedAt}
                                    </td>
                                    <td>
                                      {property?.amenitiesData?.createdAt}
                                    </td>

                                    <td>
                                      <button
                                        onClick={() =>
                                          navigateToViewPropertyListing(
                                            property?.propertydata?.id
                                          )
                                        }
                                        className="btn btn-sm btn-icon me-2 float-left btn-info"
                                        data-toggle="tooltip"
                                        data-placement="top"
                                        title=""
                                        data-original-title="View"
                                      >
                                        <FontAwesomeIcon
                                          icon={faEye}
                                          style={{ color: "white" }}
                                        />
                                      </button>
                                      <button
                                        className="btn btn-sm btn-icon   me-2  btn-danger"
                                        data-toggle="tooltip"
                                        data-placement="top"
                                        title=""
                                        data-original-title="Delete"
                                        onClick={() =>
                                          confirmDelete(
                                            property?.detailsData?.id
                                          )
                                        }
                                      >
                                        <FontAwesomeIcon
                                          icon={faTrashAlt}
                                          style={{ color: "white" }}
                                        />
                                      </button>
                                    </td>
                                  </tr>
                                );
                              })}
                          </tbody>
                          <Modal open={openConfirmation} onClose={cancelDelete}>
                            <Paper className={classes.modalPaper}>
                              <div className="confirmation-modal">
                                <div className="confirmation-content">
                                  <p style={{ marginTop: "10px" }}>
                                    Are you sure you want to delete this item?
                                  </p>
                                  <div className="row">
                                    <div className="col-md-5">
                                      <Button
                                        className="btn btn-primary text-white "
                                        style={{ marginLeft: "30px" }}
                                        onClick={() =>
                                          executeDelete(itemToDelete)
                                        }
                                      >
                                        Confirm
                                      </Button>
                                    </div>
                                    <div className="col-md-5">
                                      <Button
                                        className="btn btn-primary text-white"
                                        onClick={cancelDelete}
                                      >
                                        Cancel
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </Paper>
                          </Modal>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
    </>
  );
};

export default PropertyListing;
