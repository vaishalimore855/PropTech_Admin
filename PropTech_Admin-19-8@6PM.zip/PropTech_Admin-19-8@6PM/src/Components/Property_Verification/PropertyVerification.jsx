import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Document, Page } from "react-pdf";

//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";

import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getPropertyList } from "../../Redux/Slice/PropertyVerificationSlice";
import * as ExcelJS from "exceljs";
import { makeStyles } from "@mui/styles";
import { Button } from "@mui/material";

const PropertyVerification = () => {
  const dispatch = useDispatch();

  // Dispatch the action to fetch the property list when the component mounts
  useEffect(() => {
    dispatch(getPropertyList());
  }, [dispatch]);

  // Access the PropertyList from the Redux store
  const propertyVerifyList = useSelector(
    (state) => state.propertyverification.PropertyList
  );

  console.log("verifylist", propertyVerifyList);

  //   const { userid } = useParams();
  var navigate = useNavigate();
  //Excel Data
  const exportToExcel = () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Data");

    // Add headers
    const headers = [
      "Id",
      " Name",
      "Price",
      "feature",
      "Status",
      "CreatedAt",
      "UpdatedAt",
    ]; // Fixed header names
    worksheet.addRow(headers);

    // Add data rows
    propertyVerifyList.forEach((row) => {
      worksheet.addRow([
        row.id,
        row.name,
        row.price,
        row.feature,
        row.status,
        row.createdAt,
        row.updatedAt,
      ]); // Fixed field names
    });

    // Generate Excel file
    workbook.xlsx.writeBuffer().then((buffer) => {
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "data.xlsx";
      a.click();
      URL.revokeObjectURL(url);
    });
  };
  const navigateToEditBuyer = (id) => {
    navigate(`/edit-proprty/${id}`);
  };

  const navigateToViewPropertyVerification = (id) => {
    navigate(`/view-propertyverification/${id}`);
  };
  const token = localStorage.getItem("token");

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Property Verification</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Property Verification
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="row">
                      <div className="d-flex justify-content-end">
                        <Button
                          onClick={exportToExcel}
                          enabled={!propertyVerifyList.length}
                          variant="contained"
                          style={{
                            backgroundColor: "#3A833A",
                            marginRight: "10px",
                          }}
                        >
                          Export to Excel
                        </Button>
                      </div>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Id</th>
                              <th>Property Name</th>
                              <th>User Name</th>
                              <th>Ownership Proof</th>
                              <th>Index II Document</th>
                              <th>Verification Status</th>
                              <th>Actions</th>
                            </tr>
                          </thead>

                          <tbody style={{ textAlign: "center" }}>
                            {propertyVerifyList.map((property, index) => (
                              <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{property?.propertyData?.title}</td>
                                <td>{property?.userData?.fullname}</td>
                                <td>
                                  <div className="d-flex justify-content-center align-items-center">
                                    <a
                                      style={{ color: "blue" }}
                                      href={property?.OwnershipProof}
                                      download
                                    >
                                      {property?.OwnershipProofname}
                                    </a>
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex justify-content-center align-items-center">
                                    <a
                                      style={{ color: "blue" }}
                                      href={property?.IndexIIDoc}
                                      download
                                    >
                                      {property?.IndexIIDocname}
                                    </a>
                                  </div>
                                </td>
                                <td>
                                  {property?.propertyData?.propertyStatus ==
                                  "Verified" ? (
                                    <span class="badge badge-success">
                                      Verified
                                    </span>
                                  ) : property?.propertyData?.propertyStatus ==
                                    "In Progress" ? (
                                    <span class="badge badge-warning">
                                      In Progress
                                    </span>
                                  ) : property?.propertyData?.propertyStatus ==
                                    "Reject" ? (
                                    <span class="badge badge-danger">
                                      Reject
                                    </span>
                                  ) : (
                                    <span class="badge badge-info">
                                      Pending
                                    </span>
                                  )}
                                </td>
                                <td>
                                  <button
                                    onClick={() =>
                                      navigateToViewPropertyVerification(
                                        property.id
                                      )
                                    }
                                    className="btn btn-sm btn-icon me-2 float-left btn-info"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="View"
                                  >
                                    <FontAwesomeIcon
                                      icon={faEye}
                                      style={{ color: "white" }}
                                    />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default PropertyVerification;
