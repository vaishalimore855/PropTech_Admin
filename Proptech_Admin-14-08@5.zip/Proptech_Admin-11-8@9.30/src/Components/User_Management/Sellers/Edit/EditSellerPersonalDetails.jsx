import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getSellerbyId } from "../../../../Redux/Slice/SellerSlice";
import { useNavigate } from "react-router-dom";

const EditSellerPersonalDetails = () => {
  var navigate = useNavigate();
  const { id } = useParams();
  const token = localStorage.getItem("token");
  const dispatch = useDispatch();
  const sellerId = useSelector((state) => state.seller.Seller);
  console.log("sellerId .......", JSON.stringify(sellerId));

  const [editedSeller, setEditedSeller] = useState({
    fullname: "",
    email: "",
    phoneNumber: "",
    userrole: "seller",
    mobileverified: true,
    password: "",
  });
  useEffect(() => {
    dispatch(getSellerbyId(id));
  }, [id]);

  useEffect(() => {
    setEditedSeller({
      fullname: sellerId?.personaldata?.fullname,
      email: sellerId?.personaldata?.email,
      phoneNumber: sellerId?.personaldata?.phoneNumber,
      userrole: sellerId?.personaldata?.userrole,
      mobileverified: sellerId?.personaldata?.mobileverified,
      password: "",
    });
  }, [sellerId]);

  const handleChangeEditSellerInput = (e) => {
    const { name, value } = e.target;
    setEditedSeller({
      ...editedSeller,
      [name]: value,
    });
  };

  const handleEditProfile = (e) => {
    e.preventDefault();

    const data = {
      method: "PUT",
      body: JSON.stringify(editedSeller),
      headers: {
         "Content-Type": "application/json",
        "authorization":token
      },
    };

    fetch(`http://65.20.73.28:8090/api/users/${id}`, data)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === true) {
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }
        navigate("/sellers");
      })
      .catch((err) => console.log(err));
  };

  return (
    <>
      <ToastContainer />
      <form>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Full Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your full Name"
              name="fullname"
              // value={buyer.personaldata.fullname}
              value={editedSeller.fullname}
              onChange={(e) => handleChangeEditSellerInput(e)}
            />

            <div className="valid-feedback">Looks good!</div>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={editedSeller.phoneNumber}
              onChange={(e) => handleChangeEditSellerInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid phone Number.
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="text"
              className="form-control"
              placeholder=" Enter City"
              name="email"
              value={editedSeller.email}
              onChange={(e) => handleChangeEditSellerInput(e)}
            />
            <div className="invalid-feedback"></div>
          </div>

          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={editedSeller.password}
              onChange={(e) => handleChangeEditSellerInput(e)}
            />
            <div className="invalid-feedback">
              Please provide a valid location.
            </div>
          </div>
        </div>
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={(e) => handleEditProfile(e)}
        >
          Submit{" "}
        </button>
      </form>
    </>
  );
};

export default EditSellerPersonalDetails;
