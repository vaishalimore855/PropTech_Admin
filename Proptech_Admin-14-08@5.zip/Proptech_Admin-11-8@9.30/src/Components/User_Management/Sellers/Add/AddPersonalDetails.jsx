import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from "formik";
import axios from "axios";
const AddPersonalDetails = () => {
  var navigate = useNavigate();

  const sellerValues = {
    fullname: "",
    email: "",
    phoneNumber: "",
    userrole: "",
    mobileverified: "",
    password: "",
  };

  const [seller, setseller] = useState(sellerValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  console.log("formErrors", formErrors);
  console.log("formErrors", seller);
  const token = localStorage.getItem("token");
  const handleChangeAddSellerInput = (e) => {
    const { name, value } = e.target;
    setseller({
      ...seller,
      [name]: value,
    });
  };

  const validate = (seller) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!seller.firstName) {
      errors.firstName = "Firstname cannot be blank";
    } else if (!seller.lastname) {
      errors.lastname = "Lastname cannot be blank";
    } else if (!seller.city) {
      errors.city = "City cannot be blank";
    } else if (!seller.address) {
      errors.address = "Address cannot be blank";
    } else if (!seller.phoneNumber) {
      errors.phoneNumber = "Mobile No. cannot be blank";
    } else if (seller.phoneNumber.length > 10) {
      errors.phoneNumber = "Mobile number not valid";
    } else if (!seller.email) {
      errors.email = "Cannot be blank";
    } else if (!regex.test(seller.email)) {
      errors.email = "Invalid email format";
    } else if (!seller.password) {
      errors.password = "Cannot be blank";
    } else if (seller.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    }

    return errors;
  };

  const addSeller = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        fullname: seller.fullname,
        email: seller.email,
        phoneNumber: seller.phoneNumber,
        userrole: "seller",
        mobileverified: true,
        password: seller.password,
      }),
      headers: {
         "Content-Type": "application/json",
        "authorization":token
      },
    };

    fetch("http://65.20.73.28:8090/api/users", data)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data?.status == true) {
          //  setbuyer(buyerValues)
          toast.success(data.message);
          // navigate("/buyer");
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(seller));

    if (Object.keys(formErrors).length !== 0) {
      // addSeller();
      navigate("/sellers");
    }
  };

  return (
    <>
      <ToastContainer />
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label for="validationCustom01">Full Name </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Your full Name"
              name="fullname"
              value={seller.fullname}
              onChange={(e) => handleChangeAddSellerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.fullname}</p>
          </div>
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Phone Number</label>
            <input
              type="number"
              className="form-control"
              placeholder="Enter Phone Number"
              name="phoneNumber"
              value={seller.phoneNumber}
              onChange={(e) => handleChangeAddSellerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.phoneNumber}</p>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Email</label>
            <input
              type="email"
              className="form-control"
              placeholder="Enter Email"
              name="email"
              value={seller.email}
              onChange={(e) => handleChangeAddSellerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.email}</p>
          </div>

          <div className="col-md-6 mb-3">
            <label for="validationCustom04">Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter password"
              name="password"
              value={seller.password}
              onChange={(e) => handleChangeAddSellerInput(e)}
            />
            <p style={{ color: "red" }}>{formErrors.password}</p>
          </div>
        </div>
       
        <button
          className="btn btn-primary mt-3"
          type="submit"
          onClick={() => addSeller()}
        >
          Submit
        </button>
      </form>
    </>
  );
};

export default AddPersonalDetails;
