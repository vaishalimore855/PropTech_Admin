import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { useSelector, useDispatch } from "react-redux";
import {
  getPropertyList,
  getPropertybyId,
} from "../../../Redux/Slice/PropertyListingSlice";
import axios from "axios";

import { ToastContainer, toast } from "react-toastify";
const PropertyListing = () => {
  const { id } = useParams();
  //property list
  const dispatch = useDispatch();
  const PropertyList = useSelector(
    (state) => state.propertylisting.propertyListingList
  );
  console.log("PropertyList", PropertyList);

  useEffect(() => {
    dispatch(getPropertyList(id));
  }, []);

  //property Id
  const PropertyId = useSelector((state) => state.propertylisting.property);
  console.log("PropertyId", PropertyId);

  useEffect(() => {
    dispatch(getPropertybyId());
  }, []);

  var navigate = useNavigate();
  const navigateToViewPropertyListing = (id) => {
    navigate(`/view-propertylisting/${id}`);
  };
  const navigateToEditProperty = (id) => {
    navigate(`/edit-property/${id}`);
  };

  //DeleteByID :API
  // const deleteProperty = (id) => {
  //   axios
  //     .delete(`http://65.20.73.28:8090//api/property/${id}`)
  //     .then((response) => response.data)
  //     .then((data) => {
  //       console.log("delete response", data);
  //       if (data.status == true) {
  //         dispatch(getPropertyList());
  //         toast.success(data.message);
  //       } else {
  //         toast.error(data.message);
  //       }
  //     })
  //     .catch((err) => console.log(err));
  // };
  // useEffect(() => {
  //   deleteProperty();
  // }, []);
 return (
    <>
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Property Listing</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link href="#">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link href="#">Property Listing</Link>
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="card" style={{ overflowX: "auto" }}>
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr style={{ fontWeight: 700 }}>
                              <td>Id</td>
                              <td>Image</td>
                              <td>Title</td>
                              <td>Description</td>
                              <td>Category</td>
                              <td>Listed In</td>
                              <td>Price</td>
                              <td>Yearly Tax Rate</td>
                              <td>Association Fee</td>
                              <td>After Price Label</td>
                              <td>Before Price Label</td>
                              <td>Property Status</td>
                              <td>Address</td>
                              <td>State</td>
                              <td>City</td>
                              <td>Neighborhood</td>
                              <td>ZIP</td>
                              <td>Latitude</td>
                              <td>Longitude</td>
                              <td>Size (sq ft)</td>
                              <td>Lot Size (sq ft)</td>
                              <td>Rooms</td>
                              <td>Bedrooms</td>
                              <td>Bathrooms</td>
                              <td>Custom ID</td>
                              <td>Garages</td>
                              <td>Garage Size</td>
                              <td>Year Built</td>
                              <td>Available From</td>
                              <td>Basement</td>
                              <td>Extra Details</td>
                              <td>Roofing</td>
                              <td>Exterior Material</td>
                              <td>Structure Type</td>
                              <td>Floors No</td>
                              <td>Notes</td>
                              <td>Energy Class</td>
                              <td>Energy Index</td>
                              <td>Amenities</td>
                              <td>Video ID</td>
                              <td>Video Type</td>
                              
                              <td>Updated At</td>
                              <td>Created At</td>
                              <td>Action</td>
                            </tr>
                          </thead>
                            <tbody>
                              
                              {PropertyList &&
                              PropertyList.map((property,index)=>{
                                return(
                                  <tr>
                                    <td>{index+1}</td>
                                    <td>
                                    <div className="d-flex justify-content-center align-items-center">
                                      <img
                                        src={property?.mediaData?.images}
                                        alt=""
                                        width="100%"
                                        height="100%"
                                      />
                                    </div>
                                  </td>
                                    <td>{property?.propertydata?.title}</td>
                                    <td>{property?.propertydata?.description}</td>
                                    <td>{property?.propertydata?.category}</td>
                                  
                                    <td>{property?.propertydata?.listedIn}</td>
                                    <td>{property?.propertydata?.price}</td>
                                    <td>{property?.propertydata?.yearlyTaxRate}</td>
                                    <td>{property?.propertydata?.associationFee}</td>
                                    <td>{property?.propertydata?.afterPriceLabel}</td>
                                    <td>{property?.propertydata?.beforePriceLabel}</td>
                                    <td>{property?.propertydata?.propertyStatus}</td>
                                    <td>{property?.locationData?.address}</td>
                                    <td>{property?.locationData?.state}</td>
                                    <td>{property?.locationData?.city}</td>
                                    <td>{property?.locationData?.neighborhood}</td>
                                    <td>{property?.locationData?.zip}</td>
                                    <td>{property?.locationData?.latitude}</td>
                                    <td>{property?.locationData?.longitude}</td>
                                  
                                    <td>{property?.detailsData?.sizeInFt}</td>
                                    <td>{property?.detailsData?.lotSizeInFt}</td>
                                    <td>{property?.detailsData?.rooms}</td>
                                    <td>{property?.detailsData?.bedrooms}</td>
                                    <td>{property?.detailsData?.bathrooms}</td>
                                    <td>{property?.detailsData?.customID}</td>
                                    <td>{property?.detailsData?.garages}</td>
                                    <td>{property?.detailsData?.garageSize}</td>
                                    <td>{property?.detailsData?.yearBuilt}</td>
                                    <td>{property?.detailsData?.availableFrom}</td>
                                    <td>{property?.detailsData?.basement}</td>

                                    <td>{property?.detailsData?.extraDetails}</td>
                                    <td>{property?.detailsData?.roofing}</td>
                                    <td>{property?.detailsData?.exteriorMaterial}</td>
                                    <td>{property?.detailsData?.structureType}</td>
                                    <td>{property?.detailsData?.floorsNo}</td>

                                    <td>{property?.detailsData?.notes}</td>
                                    <td>{property?.detailsData?.energyClass}</td>
                                    <td>{property?.detailsData?.energyIndex}</td>
    
                                    <td>{property?.amenitiesData?.amenities}</td>
                                    <td>{property?.mediaData?.videoid}</td>
                                    <td>{property?.mediaData?.videotype}</td>
                                    <td>{property?.amenitiesData?.updatedAt}</td>
                                    <td>{property?.amenitiesData?.createdAt}</td>

                                    <td>
                                    <button
                                      onClick={() =>
                                        navigateToViewPropertyListing(property?.propertydata?.id)
                                      }
                                      className="btn btn-sm btn-icon me-2 float-left btn-info"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="View"
                                    >
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                  </td>
                              
                                  </tr>
                                )
                              })

                              }
                            </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
    </>
  );
};

export default PropertyListing;
