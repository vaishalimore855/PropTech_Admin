import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from "formik";
import axios from "axios";
const AddInvestorPersonalDetails = () => {

  var navigate = useNavigate();
  

  const investorValues = {
    fullname: "",
    email: "",
    phoneNumber: "",
    userrole: "",
    mobileverified: "",
    password: "",
  };

const [investor, setinvestor] = useState(investorValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const token = localStorage.getItem("token");
  console.log("formErrors", formErrors);
  console.log("investor", investor);

  const handleChangeAddInvestorInput = (e) => {
    const { name, value } = e.target;
    setinvestor({
      ...investor,
      [name]: value,
    });
  };

  const validate = (investor) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!investor.firstName) {
      errors.firstName = "Firstname cannot be blank";
    } else if (!investor.lastname) {
      errors.lastname = "Lastname cannot be blank";
    } else if (!investor.city) {
      errors.city = "City cannot be blank";
    } else if (!investor.address) {
      errors.address = "Address cannot be blank";
    } else if (!investor.phoneNumber) {
      errors.phoneNumber = "Mobile No. cannot be blank";
    } else if (investor.phoneNumber.length > 10) {
      errors.phoneNumber = "Mobile number not valid";
    } else if (!investor.email) {
      errors.email = "Cannot be blank";
    } else if (!regex.test(investor.email)) {
      errors.email = "Invalid email format";
    } else if (!investor.password) {
      errors.password = "Cannot be blank";
    } else if (investor.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    }

    return errors;
  };

  const addInvestor = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        fullname: investor.fullname,
        email: investor.email,
        phoneNumber: investor.phoneNumber,
        userrole: "investor",
        mobileverified: true,
        password: investor.password,
      }),
      headers: {
         "Content-Type": "application/json",
        "authorization":token
      },
    };

    fetch("http://65.20.73.28:8090/api/users", data)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data?.status == true) {
          //  setbuyer(investorValues)
          toast.success(data.message);
          navigate("/investor");
        } else {
          toast.error(data.message)
        }
      })
      .catch((err) => console.log(err));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(investor));

    if (Object.keys(formErrors).length !== 0) {
      // addInvestor();
      navigate("/investor")
    }
  };


  return (
    
    <>
    <ToastContainer/>
      <form onSubmit={handleSubmit}>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom01">Full Name </label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Enter Your full Name"
                            name="fullname"
                            value={investor.fullname}
                            onChange={(e) => handleChangeAddInvestorInput(e)}
                          />
                          <p style={{ color: "red" }}>{formErrors.fullname}</p>
                        </div>
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Phone Number</label>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="Enter Phone Number"
                            name="phoneNumber"
                            value={investor.phoneNumber}
                            onChange={(e) => handleChangeAddInvestorInput(e)}
                          />
                          <p style={{ color: "red" }}>
                            {formErrors.phoneNumber}
                          </p>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Email</label>
                          <input
                            type="email"
                            className="form-control"
                            placeholder="Enter Email"
                            name="email"
                            value={investor.email}
                            onChange={(e) => handleChangeAddInvestorInput(e)}
                          />
                          <p style={{ color: "red" }}>{formErrors.email}</p>
                        </div>

                        <div className="col-md-6 mb-3">
                          <label for="validationCustom04">Password</label>
                          <input
                            type="password"
                            className="form-control"
                            placeholder="Enter password"
                            name="password"
                            value={investor.password}
                            onChange={(e) => handleChangeAddInvestorInput(e)}
                          />
                          <p style={{ color: "red" }}>{formErrors.password}</p>
                        </div>
                      </div>
                      
                      <button
                        className="btn btn-primary mt-3"
                        type="submit"
                        onClick={() => addInvestor()}
                      >
                        Submit
                      </button>
                    </form>
    </>
  );
};

export default AddInvestorPersonalDetails;

