import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import {
  getBuyerList,
  getKycBuyerUserid,
} from "../../../Redux/Slice/BuyerSlice";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const Buyer = () => {
  const { userid } = useParams();
  const dispatch = useDispatch();
  const BuyerList = useSelector((state) => state.buyer.Buyers);
  console.log("BuyerList", BuyerList);
  
  var navigate = useNavigate();

  useEffect(() => {
    dispatch(getBuyerList());
    
  }, [userid]);

  const navigateToEditBuyer = (id) => {
    navigate(`/edit-buyer/${id}`);
  };

  const navigateToViewBuyer = (id) => {
    navigate(`/view-buyer/${id}`);
  };

  const navigateToKycEditBuyer = (userid) => {
    navigate(`/edit-buyer/${userid}`);
  };

  const navigateToKycViewBuyer = (userid) => {
    navigate(`/view-buyer/${userid}`);
  };

  const deletBuyer = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/users/${id}`)
      .then((response) => response.data)
      .then((data) => {
        console.log("delete buyer ", data);
        if (data.status != true) {
          dispatch(getBuyerList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        dispatch(getBuyerList());
      })
      .catch((err) => console.log(err));
  };
  //delete Buyer Kyc
  // const deletKycBuyer = (userid) => {
  //   axios
  //     .delete(`http://65.20.73.28:8090/api/users/delete-kyc/${userid}`)
  //     .then((response) => response.data)
  //     .then((data) => {
  //       console.log("delete kyc buyer ", data);
  //       if (data.status != true) {
  //         dispatch(getKycBuyerUserid());
  //         toast.success(data.message);
  //       } else {
  //         toast.error(data.message);
  //       }

  //       dispatch(getKycBuyerUserid());
  //     })
  //     .catch((err) => console.log(err));
  // };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Buyers</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">User Management Screen</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Buyers
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="/add-buyer" className="text-white">
                          + Add Buyer
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Contact</th>
                              <th>Email</th>
                              <th>User Role</th>
                              <th>KYC Status</th>
                              <th>Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {BuyerList.map((buyer) => {
                              return (
                                <tr>
                                  <td>{buyer.fullname}</td>
                                  <td>{buyer.phoneNumber}</td>
                                  <td>{buyer.email}</td>
                                  <td>{buyer.userrole}</td>
                                  <td>
                                  {
                                    buyer?.isVerifiedByAdmin == 'Verified'?
                                    <span class="badge badge-success">Verified</span>
                                    :
                                     buyer?.isVerifiedByAdmin == "Reject"?
                                    <span class="badge badge-danger">Reject</span>
                                    :
                                    <span class="badge badge-info">Pending</span>
                                  }
                                  </td>
                                  <td className="d-flex ">
                                    <button
                                      onClick={() =>
                                        navigateToViewBuyer(buyer.id)
                                      }
                                      className="btn btn-sm btn-icon  me-2  float-left btn-info"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="View"
                                    >
                                      <FontAwesomeIcon
                                        icon={faEye}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                    <button
                                      onClick={() => {
                                        navigateToEditBuyer(buyer.id);
                                      }}
                                      className="btn btn-sm btn-icon  me-2   float-left btn-primary"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Edit"
                                    >
                                      <FontAwesomeIcon
                                        icon={faPencilSquare}
                                        style={{ color: "white" }}
                                      />
                                    </button>

                                    <button
                                      className="btn btn-sm btn-icon   me-2  btn-danger"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Delete"
                                      onClick={() => deletBuyer(buyer.id)}
                                    >
                                      <FontAwesomeIcon
                                        icon={faTrashAlt}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default Buyer;
