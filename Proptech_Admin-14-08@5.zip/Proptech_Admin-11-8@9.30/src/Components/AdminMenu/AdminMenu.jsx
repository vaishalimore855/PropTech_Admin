import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { getAdminMenuList, getAdminMenuId } from "../../Redux/Slice/MenuSlice";
import { useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";

function AdminMenu() {
  const dispatch = useDispatch();
  const { id } = useParams();
  const token = localStorage.getItem("token");

  const [adminMenuData, setAdminMenuData] = useState("");
  const AdminMenuList = useSelector((state) => state.adminMenu.AdminMenuList);
  console.log("AdminMenuList", AdminMenuList);
  var navigate = useNavigate();

  console.log("adminMenuData", adminMenuData);

  const AdminMenuId = useSelector((state) => state.adminMenu.AdminMenuId);
  console.log("AdminMenuId", AdminMenuId);
  useEffect(() => {
    dispatch(getAdminMenuList());
    getAdminMenuId(id);
    setAdminMenuData(AdminMenuList);
  }, []);
  const navigateTtoEditAdminMenu = (id) => {
    navigate(`/edit-adminmenu/${id}`);
  };

  const deletAdminMenu = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/adminmenus/${id}`,{
        headers: {
            authorization:token }
            
        
      })
      .then((response) => response.data)
      .then((data) => {
        console.log("delete admin menu ", data);
        if (data.status != true) {
          dispatch(AdminMenuList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        dispatch(AdminMenuList());
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="rtl">
      <div id="main">
        <div className="main-content">
          <div className="container">
            {/* <ToastContainer/> */}
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Admin Menu</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/Dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Admin Menu
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body" style={{ height: "200%" }}>
                    <div className="pt-4 pb-4 text-left">
                      <button
                        // class="btn btn-primary"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link to="/AddMenu" className="text-white">
                          + Add
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                            <tr>
                              <th>Title</th>
                              <th>Icon</th>
                              <th>ParentId</th>
                              <th>Path</th>
                              <th>Priority</th>
                              <th>SubNav</th>
                              <th>Action</th>
                            </tr>
                          </thead>

                          <tbody>
                            {AdminMenuList &&
                              AdminMenuList.map((menu) => {
                                return (
                                  <>
                                    <tr>
                                      <td>{menu.title}</td>
                                      <td>{menu.icon}</td>
                                      <td>{menu.parentid}</td>
                                      <td>{menu.path}</td>
                                      <td>{menu.priority}</td>
                                      <td>{menu.subNav}</td>
                                      <td className="d-flex justify-content-center align-items-center ">
                                        <button
                                          onClick={() => {
                                            navigateTtoEditAdminMenu(menu.id);
                                          }}
                                          className="btn btn-sm btn-icon  me-2   float-left btn-primary"
                                          data-toggle="tooltip"
                                          data-placement="top"
                                          title=""
                                          data-original-title="Edit"
                                        >
                                          <FontAwesomeIcon
                                            icon={faPencilSquare}
                                            style={{ color: "white" }}
                                          />
                                        </button>

                                        <button
                                          className="btn btn-sm btn-icon   me-2  btn-danger"
                                          data-toggle="tooltip"
                                          data-placement="top"
                                          title=""
                                          data-original-title="Delete"
                                          onClick={() =>
                                            deletAdminMenu(menu.id)
                                          }
                                        >
                                          <FontAwesomeIcon
                                            icon={faTrashAlt}
                                            style={{ color: "white" }}
                                          />
                                        </button>
                                      </td>
                                    </tr>
                                  </>
                                );
                              })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  {/* </div> */}
                </div>
              </div>
            </div>
          </div>
          {/* <!-- end::main-content --> */}
        </div>
        {/* <!-- end::main --> */}
      </div>
    </div>
  );
}

export default AdminMenu;
