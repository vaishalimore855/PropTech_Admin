import React, { useState,useEffect } from "react";
import { Link, useNavigate,useParams } from "react-router-dom";
import { getManagerbyId } from "../../Redux/Slice/ManagerSlice";
import { useSelector, useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useFormik } from "formik";
import axios from "axios";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
const TabPanel = ({ children, value, index }) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
};


const EditManager = () => {
  var navigate = useNavigate();
  const { id } = useParams();
  const dispatch = useDispatch();
  const Manager = useSelector((state) => state.ManagerData.Manager);
  const [currentTab, setCurrentTab] = useState(0);
  const handleChangeTab = (event, newValue) => {
    setCurrentTab(newValue);
  };
 useEffect(() => {
  dispatch(getManagerbyId(id));
}, [id]);

  const token = localStorage.getItem("token");
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);


 const ManagerValues = {
    name: "",
    price: "",
    feature: "",
    status: "",
  };

  const [managers, setmanagers] = useState(ManagerValues);

  useEffect(() => {
    setmanagers({
      name: Manager?.name,
      price: Manager?.price,
      feature: Manager?.feature,
      status: Manager?.status
    });
  }, [Manager]);

  
  const handleChangeAddManagerInput = (e) => {
    const { name, value } = e.target;
    setmanagers({
      ...Manager,
      [name]: value,
    });
  };

  
  const validate = (Manager) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!managers.name) {
      errors.name = "Plan name cannot be blank";
    } else if (!managers.price) {
      errors.price = "Price cannot be blank";
    } else if (!managers.feature) {
      errors.feature = "Feature cannot be blank";
    } else if (!managers.status) {
      errors.status = "Status cannot be blank";
    } 

    return errors;
  };

  const editManager = () => {
    const data = {
      method: "PUT",
      body: JSON.stringify({
        name: managers.name,
        price: managers.price,
        feature: managers.feature,
        status: managers.status,
      }),
      headers: {
         "Content-Type": "application/json",
         "authorization":token
      },
    };
    console.log("ManagersData",data);
    fetch(`http://65.20.73.28:8090/api/Managers/${id}`, data)
      .then((response) => response.json())
      .then((data) => {
        console.log("data message", data);
        if (data?.status == true) {
          toast.success(data.message);
          navigate("/Manager");
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => console.log(err));
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(Manager));

    if (Object.keys(formErrors).length == 0) {
      // addManager();
      navigate("/Manager")
    }
  };
  
  return (
        <div id="main">
          <div className="main-content">
            <div className="container">
              <ToastContainer />

              {/* begin::page-header  */}
              <div className="page-header mt-5">
                <h4>Edit Manager</h4>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <Link to="/Dashboard">Home</Link>
                    </li>

                    <li className="breadcrumb-item">
                      <Link to="/Manager">Managers</Link>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">
                       Edit Manager
                    </li>
                  </ol>
                </nav>
              </div>

              {/* end::page-header */}

              <div className="row">
                <div className="col-md-12">
                  {/* <div className="card"> */}
                  <div>
                    <Tabs value={currentTab} onChange={handleChangeTab} start>
                      <Tab label="Edit Manager Details" />
                    </Tabs>
                  </div>
                  {/* </div> */}
                </div>
              </div>

              <div className="card" style={{ height: "300px",height:"auto", marginTop: "30px" }}>
                <div>
                  <TabPanel value={currentTab} index={0}>
                  <form onSubmit={handleSubmit}>
            <div className="row">
              <div className="col-md-4 mb-3">
                <label for="validationCustom01">First Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter First Name"
                  name="firstname"
                  value={Manager.firstname}
                  onChange={(e) => handleChangeAddManagerInput(e)}
                />
                <p style={{ color: "red" }}>{formErrors.fullname}</p>
              </div>
              <div className="col-md-4 mb-3">
                <label for="validationCustom04">Last Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Last Name"
                  name="lastname"
                  value={Manager.lastname}
                  onChange={(e) => handleChangeAddManagerInput(e)}
                />
                <p style={{ color: "red" }}>{formErrors.phoneNumber}</p>
              </div>
              <div className="col-md-4 mb-3">
                <label for="validationCustom04">Phone Number</label>
                <input
                  type="number"
                  className="form-control"
                  placeholder="Enter Phone Number"
                  name="lastname"
                  value={Manager.phoneNumber}
                  onChange={(e) => handleChangeAddManagerInput(e)}
                />
                <p style={{ color: "red" }}>{formErrors.phoneNumber}</p>
              </div>
            </div>
            <div className="row mt-3">
              <div className="col-md-6 mb-3">
                <label for="validationCustom04">Email</label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter Phone Number"
                  name="email"
                  value={Manager.email}
                  onChange={(e) => handleChangeAddManagerInput(e)}
                />
              </div>

              <div className="col-md-6 mb-3">
                <label for="validationCustom04">Password</label>
                <input
                  type="password"
                  className="form-control"
                  placeholder="Enter Password"
                  name="password"
                  onChange={(e) => handleChangeAddManagerInput(e)}
                />
              </div>
              <div className="row mt-3">
              <div className="col-md-4 mb-3">
                <label for="validationCustom04">Manager Role</label>
                <select
                className="form-control"
                name="status"
                onChange={(e) => handleChangeAddManagerInput(e)}
              >
                <option value="">Select role</option>
                <option value="true">Property Manager</option>
                <option value="false">Admin</option>
              </select>
                <p style={{ color: "red" }}>{formErrors.password}</p>
              </div>
              <div className="col-md-4 mb-3">
                <label for="validationCustom04">Access Level</label>
                <select
                className="form-control"
                name="status"
                onChange={(e) => handleChangeAddManagerInput(e)}
              >
                <option value="">Select Access</option>
                <option value="true">User Management</option>
                <option value="false">Manager Management</option>
                <option value="false">Manager Management</option>
              </select>
                <p style={{ color: "red" }}>{formErrors.password}</p>
              </div>
              <div className="col-md-4 mb-3">
                <label for="validationCustom04">Status</label>
                <select
                className="form-control"
                name="status"
                onChange={(e) => handleChangeAddManagerInput(e)}
              >
                <option value="">Select Status</option>
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
                <p style={{ color: "red" }}>{formErrors.password}</p>
              </div>
            </div>
            </div> 
            <button
              className="btn btn-primary mt-3"
              type="submit"
              onClick={() => editManager()}
            >
              Submit
            </button>
          </form>
              </TabPanel>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  
};

export default EditManager;
