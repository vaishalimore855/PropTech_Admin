import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
//icons
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye } from "@fortawesome/free-solid-svg-icons";
import { faPencilSquare } from "@fortawesome/free-solid-svg-icons";
import { faTrash, faTrashAlt } from "@fortawesome/free-solid-svg-icons";

import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { getManagersList } from "../../Redux/Slice/ManagerSlice";
const Managers = () => {
  const dispatch = useDispatch();

  // Dispatch the action to fetch the property list when the component mounts
  useEffect(() => {
    dispatch(getManagersList());
  }, [dispatch]);

  // Access the PropertyList from the Redux store
  const ManagerList = useSelector(
    (state) => state.ManagerData.Managers
  );

  console.log("list", JSON.stringify(ManagerList));

  //   const { userid } = useParams();
  var navigate = useNavigate();

  const navigateToEditManager = (id) => {
    navigate(`/edit-manager/${id}`);
  };

  const navigateToViewPSubscription = (id) => {
    navigate(`/view-manager/${id}`);
  };
  const token = localStorage.getItem("token");

  const deletManager = (id) => {
    axios
      .delete(`http://65.20.73.28:8090/api/managers/${id}`,{
        headers: {
          authorization:token }
      }
      )
      .then((response) => response.data)
      .then((data) => {
        console.log("delete Manager ", data);
        if (data.status != true) {
          dispatch(getManagersList());
          toast.success(data.message);
        } else {
          toast.error(data.message);
        }

        dispatch(getManagersList());
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
      {/* <!-- begin::main --> */}
      <div id="main">
        {/* <!-- begin::main-content --> */}
        <main className="main-content">
          <div className="container">
            <ToastContainer />
            {/* <!-- begin::page-header --> */}
            <div className="page-header mt-5">
              <h4>Managers</h4>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/homepage">Home</Link>
                  </li>
                  <li className="breadcrumb-item">
                    <Link to="#">Manager Management</Link>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                  Manager List
                  </li>
                </ol>
              </nav>
            </div>
            {/* <!-- end::page-header --> */}

            <div className="row">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-body">
                    <div className="pt-4 pb-4 text-left">
                      <button
                        type="button"
                        className="btn btn-primary btn-rounded  "
                      >
                        <Link
                          to="/add-manager"
                          className="text-white"
                        >
                          + Add Manager
                        </Link>
                      </button>
                    </div>
                    <div className="card">
                      <div className="card-body">
                        <table
                          id="example2"
                          className="table table-striped table-bordered"
                        >
                          <thead>
                         <tr>
                          <th>Sr No</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Email</th>
                          <th>Phone Number</th>
                          <th>Role</th>
                          <th>Access Level</th>
                          <th>Action</th>
                          </tr>
                          </thead>

                          <tbody style={{ textAlign: "center" }}>
                            {ManagerList.map((manager, index) => (
                              <tr key={index}>
                                <td>{index+1}</td>
                                <td>{manager?.userData?.firstname}</td>
                                <td>{manager?.userData?.lastname}</td>
                                <td>{manager?.userData?.email}</td>
                                <td>{manager?.userData?.phoneNumber}</td>
                                <td>{manager?.roles}</td>
                                <td>{manager?.userData?.menu}</td>
                                
                                <td>
                                  <button
                                    onClick={() =>
                                      navigateToViewPSubscription(manager.userData?.id)
                                    }
                                    className="btn btn-sm btn-icon me-2 float-left btn-info"
                                    data-toggle="tooltip"
                                    data-placement="top"
                                    title=""
                                    data-original-title="View"
                                  >
                                    <FontAwesomeIcon
                                      icon={faEye}
                                      style={{ color: "white" }}
                                    />
                                  </button>

                                  <button
                                      onClick={() => {
                                        navigateToEditManager(manager.userData?.id);
                                      }}
                                      className="btn btn-sm btn-icon  me-2   float-left btn-primary"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Edit"
                                    >
                                      <FontAwesomeIcon
                                        icon={faPencilSquare}
                                        style={{ color: "white" }}
                                      />
                                    </button>

                                    <button
                                      className="btn btn-sm btn-icon   me-2  btn-danger"
                                      data-toggle="tooltip"
                                      data-placement="top"
                                      title=""
                                      data-original-title="Delete"
                                      onClick={() => deletManager(manager.userData?.id)}
                                    >
                                      <FontAwesomeIcon
                                        icon={faTrashAlt}
                                        style={{ color: "white" }}
                                      />
                                    </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        {/* <!-- end::main-content --> */}
      </div>
      {/* <!-- end::main --> */}
    </div>
  );
};

export default Managers;
