import React, { useEffect, useState } from "react";
// import Profile from "../admin/Profile";
import { Link, useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { getAdminData, adminLogin } from "../../Redux/Slice/AuthSlice";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Login() {
  const AdminDetails = useSelector((state) => state.authentication.Admin);
  console.log("AdminDetails", AdminDetails);
  const dispatch = useDispatch();
  var navigate = useNavigate();

  const values = {
    username: "",
    password: "",
  };

  const [auth, setAuth] = useState(values);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    dispatch(getAdminData());
  }, []);

  const handleChangeAuthInput = (e) => {
    const { name, value } = e.target;
    setAuth({
      ...auth,
      [name]: value,
    });
  };

  const Login = () => {
    const data = {
      method: "POST",
      body: JSON.stringify({
        email: auth.username,
        password: auth.password,
      }),
      headers: {
         "Content-Type": "application/json",
      },
    };

    fetch("http://65.20.73.28:8090/api/admins/login", data)
      .then((response) => response.json())
      .then((data) => {
        console.log("login response", data);
        
        if (data.status == true) {
          toast.success(data.message);
          navigate("/dashboard");
          const jsonData = JSON.stringify(
            `Email-ID:${data.user.email}, RoleNo:${data.user.role}`
          );
          localStorage.setItem("myData", jsonData);
          localStorage.setItem("token", data.token);
          localStorage.setItem("adminId", data.user.id);
        } else {
          toast.error(data.message);
        }
      })
      .catch((err) => toast.error(err));
  };
  console.log("auth", auth);
  const validate = (auth) => {
    let errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;

    if (!auth.username) {
      errors.username = "Username cannot be blank";
    } else if (!auth.password) {
      errors.password = "Password cannot be blank";
    } else if (auth.password.length < 4) {
      errors.password = "Password must be more than 4 characters";
    }
    return errors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(auth));
    setIsSubmitting(true);
  };

  useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmitting) {
      Login();
    }
  }, [formErrors]);

  // localStorage
  const adminLoginData = localStorage.getItem("myData");
  console.log("adminLoginData", adminLoginData);

  return (
    <div className="form-membership">
      <ToastContainer />
      <div className="form-wrapper">
        {/* logo  */}
        <div className="mb-4" id="logo">
          <h2 style={{ fontWeight: "bold" }}>PropTech</h2>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <input
              type="text"
              name="username"
              value={auth.username}
              onChange={(e) => handleChangeAuthInput(e)}
              className="form-control"
              placeholder="Username or email"
            />
            <p style={{ color: "red" }}>{formErrors.username}</p>
          </div>
          <div className="form-group mb-3">
            <input
              type="password"
              name="password"
              value={auth.password}
              onChange={(e) => handleChangeAuthInput(e)}
              className="form-control"
              placeholder="Password"
            />
            <p style={{ color: "red" }}>{formErrors.password}</p>
          </div>
          <button
            className="btn btn-primary btn-block "
            // onClick={(e) => handleChangeAuthInput(e)}
            onClick={() => Login()}
          >
            Log In
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
